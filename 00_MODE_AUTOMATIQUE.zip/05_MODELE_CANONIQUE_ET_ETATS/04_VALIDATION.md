# 05_MODELE_CANONIQUE_ET_ETATS — Validation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Definir les etats du monde, leur persistance et leurs transitions.

**Étape Validation :** Prouver que ca marche ET que c'est complet. Le test doit porter sur le CONTENU, pas seulement sur la mecanique.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/05_MODELE_CANONIQUE_ET_ETATS/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/identity.json`
- `data/canon/perimetre_contenu.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/world_states.json` | `etats` | **6** |
| `data/canon/world_states.json` | `transitions` | **6** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ce domaine ne cree aucune entite nommee. Il ne doit donc en inventer aucune.


## Système exigé : l'état émotionnel du joueur

Plusieurs promesses de la bible en dépendent, la plus explicite étant : « les
Mues changent de forme selon l'**émotion dominante du joueur** ».

Produire dans `data/canon/world_states.json` une section `emotion_joueur` :

- les **émotions suivies** (au moins 4) et ce qui les fait monter ou descendre ;
- comment l'émotion **dominante** est calculée ;
- comment le joueur la **perçoit** — sinon le système est invisible et donc
  inexistant pour lui ;
- sa **persistance** en sauvegarde.

C'est ce domaine qui le produit. `21_CREATURES_ET_BOSS` le consomme.

## Système exigé : le contrat des cas limites

Aucun domaine ne peut improviser sa propre réponse à une situation anormale :
ce domaine la fixe une fois, et les autres l'appliquent.

`data/canon/world_states.json`, section `cas_limites`, au minimum **huit
entrées**, chacune avec la situation, le comportement exact, et ce que le joueur
voit :

- **inventaire plein** au moment d'un ramassage ou d'une récompense de quête ;
- **ressource à zéro** alors qu'un système l'exige (graine, énergie, ingrédient) ;
- **sauvegarde corrompue ou illisible** — la copie de secours de
  `07_MIGRATION_SAUVEGARDES` est chargée, le joueur est prévenu, jamais un écran
  d'erreur nu ;
- **quitter en plein événement** (festival, anomalie, dialogue) et recharger ;
- **rejouer un festival déjà vécu** : ce qui change, ce qui se répète ;
- **PNJ absent ou parti** au moment où une quête l'exige ;
- **objet de quête perdu, vendu ou détruit** : comment la quête reste finissable ;
- **première seconde de jeu** et **dernière** : état initial complet, état final.

Chacun de ces cas doit avoir un test. Un cas limite sans test est une supposition.

## Fichiers exacts a modifier

- `tests/test_world_states.gd`
- `docs/reports/05_MODELE_CANONIQUE_ET_ETATS/04_VALIDATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_world_states.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/05_MODELE_CANONIQUE_ET_ETATS/04_VALIDATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0040-modele_canon`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0040` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0040`
Domaine : `05_MODELE_CANONIQUE_ET_ETATS`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
