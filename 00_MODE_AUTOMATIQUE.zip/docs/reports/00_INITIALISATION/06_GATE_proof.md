# Preuve — JARDINS-0007

## Prompt

- ID : `JARDINS-0007`
- Domaine : `00_INITIALISATION`
- Étape : `06_GATE`
- Date : `2026-09-20 22:46:00 +02:00`

## Gate du domaine

Le projet Godot cible existe, son canon d'identité contient les minimums
requis, la scène principale charge le bootstrap, et le test vérifie le contenu
canonique ainsi que les erreurs attendues.

## Comptes par section

| Section | Compte | Minimum |
|---|---:|---:|
| `canonical_characters` | 1 | 1 |
| `biomes` | 7 | 7 |
| `perimetre_contenu` | 1 | 1 |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| Godot console `--headless --path C:\Users\daric\OneDrive\Bureau\Les-Jardins-de-l-Heure-Creuse-V4-AUTO --script res://tests/test_boot.gd` | 0 | PASS |
| `python tools/audit_chaine.py` | 0 | 0 constat |
| `python tools/audit_qualite_prompts.py` | 0 | 0 constat |
| `python tools/audit_livrables.py` | 0 | 0 constat |
| `python tools/verifier_branchement_pipeline.py` | 0 | 10/10 |

## Corrections d'audit liées au gate

`audit_qualite_prompts.py` ignore désormais les chemins explicitement déclarés
comme livrables du prompt contrôlé. `audit_livrables.py` ne signale les
minimums et les entités d'un domaine qu'après la fin de ce domaine ; les
domaines futurs ne sont pas des défauts de l'état courant.

## Décision

`PASS` — domaine `00_INITIALISATION` terminé.
