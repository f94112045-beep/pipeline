<!-- ID: JARDINS-0087 -->
# 10_MENUS_UX_ACCESSIBILITE — Implementation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Menus, options, et accessibilite reelle : tailles de texte, contrastes, remappage des touches.

**Étape Implementation :** Produire le contenu reel. C'est l'etape ou les quantites doivent etre atteintes.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/10_MENUS_UX_ACCESSIBILITE/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/world_states.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/npc_life.json` — produit plus tard par `17_PNJ_HORAIRES_RELATIONS_DIALOGUES`
- `data/canon/quests.json` — produit plus tard par `18_QUETES_ET_PROGRESSION`
- `data/canon/cultures_craft.json` — produit plus tard par `13_CULTURES_JARDINAGE_SAISONS`
- `data/canon/factions.json` — produit plus tard par `15B_FACTIONS_ET_COMMERCE`
- `data/canon/daily_loop.json` — produit plus tard par `20B_BOUCLE_QUOTIDIENNE`
- `data/canon/exploration.json` — produit plus tard par `19_EXPLORATION_ET_ANOMALIES`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/accessibility_ui.json` | `options` | **8** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ce domaine ne cree aucune entite nommee. Il ne doit donc en inventer aucune.

## Système exigé : les indications — comment le joueur SAIT

Un monde riche que le joueur ne peut pas lire est un monde inutile. Aucun
domaine ne produit aujourd'hui l'information ; ce domaine en écrit le contrat,
`32_UI_ICONES_CODEX` en dessine les signes.

`data/canon/accessibility_ui.json`, section `indications`, au minimum **huit
entrées**. Pour chacune : l'état source, le domaine qui le produit, le signe
montré, où il apparaît, et quand il disparaît.

Au minimum : un PNJ a quelque chose de neuf à dire · une culture est mûre · une
quête a avancé · un événement approche · une relation a changé de palier · une
conséquence différée vient de se déclencher · quelque chose a été perdu · une
anomalie est active à proximité.

**Règle :** un état qu'aucune indication ne montre est un état invisible, donc
inexistant pour le joueur. Chaque domaine d'état doit avoir au moins une entrée
ici, ou déclarer explicitement que son état est volontairement silencieux.

## Système exigé : la reprise après une longue absence

Au chargement d'une partie vieille de plusieurs semaines, un écran de reprise —
pas un menu, un rappel : la quête en cours et son étape, la dernière décision
prise, les cultures plantées et leur échéance, les promesses faites à des PNJ,
la saison et le jour. Quatre éléments minimum, et l'écran doit être ignorable
d'une touche.

## Fichiers exacts a modifier

- `data/canon/accessibility_ui.json` — **ce prompt en est le producteur**
- `src/godot/ui_menus.gd`
- `docs/reports/10_MENUS_UX_ACCESSIBILITE/02_IMPLEMENTATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_accessibility.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/10_MENUS_UX_ACCESSIBILITE/02_IMPLEMENTATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0087-menus_ux_acc`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0087` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0087`
Domaine : `10_MENUS_UX_ACCESSIBILITE`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
