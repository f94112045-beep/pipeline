<!-- ID: JARDINS-0208 -->
# 23B_SECONDE_MEMOIRE — Validation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Recommencer en conservant certaines choses : le Carnet des Continuites, des variantes de graines, des evenements supplementaires, et des PNJ qui se souviennent vaguement d'une autre partie. Cela exige une meta-sauvegarde, distincte de la sauvegarde de partie.

**Étape Validation :** Prouver que ca marche ET que c'est complet. Le test doit porter sur le CONTENU, pas seulement sur la mecanique.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/23B_SECONDE_MEMOIRE/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/save_contract.json`
- `data/canon/narrative.json`
- `data/canon/cultures_craft.json`
- `data/canon/cuisine.json`
- `data/canon/factions.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/meta_save.json` | `donnees_conservees` | **6** |
| `data/canon/meta_save.json` | `deblocages` | **8** |
| `data/canon/meta_save.json` | `variantes_de_depart` | **4** |
| `data/canon/meta_save_migration.json` | `versions_supportees` | **2** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Inventaire nominatif — ce qui doit exister, nommement

**La meta-sauvegarde est un fichier SEPARE** de la sauvegarde de partie.
Effacer une partie ne doit pas effacer la seconde memoire, et inversement.

- **Six donnees conservees** au minimum : entrees du Carnet, variantes de
  graines, recettes decouvertes, fins deja atteintes, cosmetiques du refuge,
  reconnaissances de PNJ.
- **Huit deblocages** : ce que la seconde memoire rend accessible qui ne l'etait
  pas -- evenements supplementaires, dialogues alternatifs, acces anticipes.
- **Quatre variantes de depart.**
- **Sa propre migration** : ce fichier survivra a plusieurs versions du jeu.
  Meme exigence que `07_MIGRATION_SAUVEGARDES` : version ecrite dans le fichier,
  chaine de migration, copie de secours.

Regle : la seconde memoire **ne rend pas plus puissant**, elle ouvre d'autres
interpretations du monde.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **seconde memoire**
- **Carnet des Continuites**
- **jardins impossibles**

## Système exigé : le sort des six états à la seconde mémoire

Pour chacun des six états nommés dans `06_SAUVEGARDE_ET_CONFIGURATION`, dire
**conservé**, **remis à zéro** ou **partiellement conservé**, et pourquoi.

Rappel de la règle du domaine : la seconde mémoire ne rend pas plus puissant.
Conserver l'influence des factions déséquilibrerait une nouvelle partie ;
conserver une reconnaissance vague des PNJ ne la déséquilibre pas.

## Fichiers exacts a modifier

- `tests/test_meta_save.gd`
- `docs/reports/23B_SECONDE_MEMOIRE/04_VALIDATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_meta_save.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/23B_SECONDE_MEMOIRE/04_VALIDATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0208-seconde_memo`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0208` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0208`
Domaine : `23B_SECONDE_MEMOIRE`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
