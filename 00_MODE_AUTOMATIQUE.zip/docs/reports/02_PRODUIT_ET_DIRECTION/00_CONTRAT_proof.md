# Preuve — JARDINS-0015

## Prompt

- ID : `JARDINS-0015`
- Domaine : `02_PRODUIT_ET_DIRECTION`
- Étape : `00_CONTRAT`
- Date : `2026-09-20 22:57:00 +02:00`

## Contrat établi

Le domaine produira le canon chiffré du périmètre et le profil visuel
canonique, sans inventer d'entités narratives. Les cibles proviennent de
`00_PERIMETRE_CONTENU.md` et les règles visuelles du canon technique commun.

## Comptes

| Livrable | Section | Minimum | Produit à cette étape |
|---|---|---:|---:|
| `data/canon/perimetre_contenu.json` | `categories` | 8 | 0 — contrat |
| `data/canon/visual_profile.json` | `palette` | 1 | 0 — contrat |
| `data/canon/visual_profile.json` | `regles` | 4 | 0 — contrat |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| `python tools/audit_qualite_prompts.py` | 0 | PASS |
| `python tools/audit_chaine.py` | 0 | PASS |
| `python tools/audit_livrables.py` | 0 | PASS |

## Hashes

| Fichier | SHA-256 |
|---|---|
| `02_PRODUIT_ET_DIRECTION/00_CONTRAT.md` | `ABD71832091EA5DD27D198619DF48D1839517466E2EE230DC4A986F39368788A` |

## Décision

`PASS` — contrat établi ; aucune production de canon à cette étape.
