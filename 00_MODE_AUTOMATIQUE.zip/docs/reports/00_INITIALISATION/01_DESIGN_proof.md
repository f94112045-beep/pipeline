# Preuve — JARDINS-0002

## Prompt

- ID : `JARDINS-0002`
- Domaine : `00_INITIALISATION`
- Étape : `01_DESIGN`
- Date : `2026-09-20 22:39:00 +02:00`

## Conception arrêtée

`identity.json` sera le canon d'identité racine, avec des entrées
référencées par identifiant stable :

- `canonical_characters` : au minimum le joueur `character.semeur` ;
- `biomes` : les sept biomes canoniques de la Bible, sans renommage ;
- `perimetre_contenu` : l'objet des cibles chiffrées du périmètre ;
- `world_name`, `great_event`, `refuge` et `key_objects` porteront les noms
  canoniques utiles aux scènes et au bootstrap.

Le projet Godot utilisera `project.godot` comme point d'entrée, une scène
`scenes/main.tscn` avec un nœud racine `Main`, et
`src/godot/main.gd` comme script de démarrage. Le test `tests/test_boot.gd`
sera produit par l'étape de correction si la validation le requiert.

## Comptes par section

Cette étape est une étape de design : aucune production de canon ou de code
n'est autorisée.

| Section | Minimum demandé | Produit à cette étape |
|---|---:|---:|
| `canonical_characters` | 1 | 0 — schéma conçu, production reportée à `JARDINS-0003` |
| `biomes` | 7 | 0 — liste conçue, production reportée à `JARDINS-0003` |
| `perimetre_contenu` | 1 | 0 — structure conçue, production reportée à `JARDINS-0003` |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| `python tools/audit_chaine.py` | 0 | PASS |
| `python tools/audit_livrables.py` | 0 | PASS technique — projet encore en production par `JARDINS-0003` |
| Test Godot | — | **NON APPLICABLE À CETTE ÉTAPE** — cette étape ne produit aucun code |

## Hashes des entrées

Les hashes des documents directeurs sont ceux consignés dans
`00_CONTRAT_proof.md` ; la conception s'appuie sur ces mêmes sources.

## Décision

`PASS` — conception complète, aucune production attendue à cette étape, et
vérifications applicables passées.
