<!-- ID: JARDINS-0180 -->
# 20B_BOUCLE_QUOTIDIENNE — Validation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

La journee se termine par une EVOLUTION VISIBLE du monde, pas par une simple sauvegarde. C'est le coeur du concept : observer, choisir une intention, recolter, explorer, faire un choix, ameliorer le refuge, voir une consequence, debloquer une question.

**Étape Validation :** Prouver que ca marche ET que c'est complet. Le test doit porter sur le CONTENU, pas seulement sur la mecanique.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 378 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/20B_BOUCLE_QUOTIDIENNE/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/calendar.json`
- `data/canon/cultures_craft.json`
- `data/canon/npc_life.json`
- `data/canon/world_architecture.json`
- `data/canon/quests.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/daily_loop.json` | `phases` | **8** |
| `data/canon/daily_loop.json` | `signes_du_jour` | **6** |
| `data/canon/daily_loop.json` | `evolutions_nocturnes` | **6** |
| `data/canon/daily_loop.json` | `consequences_differees` | **5** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Inventaire nominatif — ce qui doit exister, nommement

**Les huit phases d'une journee** (bible, section boucle de gameplay) :

1. observer le monde · 2. choisir une intention · 3. recolter ou fabriquer ·
4. explorer ou resoudre · 5. faire un choix relationnel ou historique ·
6. ameliorer le refuge · 7. voir une consequence apparaitre ·
8. debloquer une nouvelle question.

**Les six signes du jour**, consultes a la sortie du refuge : couleur du ciel ·
sons des regions voisines · croissance des cultures · souvenirs apparus pendant
la nuit · demandes des habitants · anomalies annoncant un evenement rare.

**Le repos** : dormir clot la journee, declenche les evolutions nocturnes et
sauvegarde. Il doit etre possible de rentrer avant la nuit **ou** de continuer
malgre elle -- le risque fait partie de la boucle.

**Les evolutions nocturnes** : croissance des cultures · apparition de souvenirs ·
reconfiguration de certaines ruines · deplacement de creatures · evolution d'une
relation · avancement d'un evenement differe.

**Les consequences differees** : une decision anodine modifie un festival, un
biome ou le destin d'un personnage **plusieurs cycles plus tard**. Au moins cinq
doivent etre canonisees, avec leur delai.

Les journees se groupent en **cycles de sept jours** (voir `20_TEMPS`).

Un compte protege du vide ; il ne protege pas de l'oubli.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Maison-Pepiniere**
- **Graines d'Instant**
- **Dernier Cycle**

## Fichiers exacts a modifier

- `tests/test_daily_loop.gd`
- `docs/reports/20B_BOUCLE_QUOTIDIENNE/04_VALIDATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_daily_loop.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/20B_BOUCLE_QUOTIDIENNE/04_VALIDATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0180-boucle_quoti`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0180` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0180`
Domaine : `20B_BOUCLE_QUOTIDIENNE`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
