<!-- ID: JARDINS-0216 -->
# 24_PIPELINE_ASSETS — Correction

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Brancher la chaine sur le moteur Blender et verifier une production de bout en bout.

**Étape Correction :** Corriger ce que la validation a refuse, a la source. Jamais de rustine sur la sortie.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/24_PIPELINE_ASSETS/`.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/asset_manifest.json` | `assets` | **1** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ce domaine ne cree aucune entite nommee. Il ne doit donc en inventer aucune.


## Le moteur d'assets du projet

Les images passent par `../_PIPELINE_BLENDER/`, les sons par
`../_PIPELINE_AUDIO/`. Ce domaine ne crée pas de pipeline : il **branche** ceux
qui existent et prouve qu'ils produisent de bout en bout.

```bash
python ../_PIPELINE_BLENDER/build_asset.py --fiche ../_PIPELINE_BLENDER/fiches/<ID>.json
python ../_PIPELINE_BLENDER/verifier_bibliotheque.py
```

**Lecture obligatoire :** `../_PIPELINE_BLENDER/GUIDE_OUTILS.md`,
`../_PIPELINE_BLENDER/GUIDE_ECRIRE_UN_BUILDER.md` et
`../_PIPELINE_BLENDER/art_direction.json`.

**Caduc dans ce prompt :** toute méthode de génération alternative — Pillow
procédural pour un sprite, ComfyUI, Stable Diffusion, LoRA, hybride. Aucun
prompt de la chaîne ne réinvente de méthode : le canon tranche pour tous les
domaines à la fois. Pillow ne sert qu'aux cas où il n'y a rien à modéliser
(cadres 9-slice, polices bitmap, découpe de planches, planches de contact), via
les scripts du moteur.

## Fichiers exacts a modifier

- `tests/test_asset_pipeline.gd`
- `docs/reports/24_PIPELINE_ASSETS/05_CORRECTION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_asset_pipeline.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/24_PIPELINE_ASSETS/05_CORRECTION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0216-pipeline_ass`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0216` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0216`
Domaine : `24_PIPELINE_ASSETS`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
