# Mode automatique — le protocole de boucle

> Ce document ne remplace rien. Les 406 prompts, les 7 étapes, les gates, les
> quantités, la bible et le contrat commun sont **identiques** à la chaîne
> manuelle. Seule change la façon de passer d'un prompt au suivant.
>
> Dans la chaîne manuelle, l'agent s'arrête après chaque gate et attend `go`.
> Ici, **il enchaîne de lui-même**, et ne s'arrête que sur blocage réel.

---

## La boucle

Après chaque prompt, exécuter ces sept opérations dans cet ordre, sans en
sauter aucune :

1. **Exécuter** le prompt courant, intégralement, selon ses propres règles.
2. **Écrire la preuve** dans `docs/reports/<domaine>/<étape>_proof.md`, avec la
   commande lancée, son code retour et les comptes section par section.
3. **Prononcer le gate** : `PASS`, `FAIL` ou `BLOCKED`, selon les critères
   écrits dans le prompt — pas selon l'impression d'avoir bien travaillé.
4. **Inscrire le résultat** : mettre à jour la ligne du prompt dans
   `PROMPT_DEPENDENCY_AUDIT.csv` (colonne `status`) et ajouter une ligne au
   journal `docs/evidence/JOURNAL_AUTO.md` (voir le format plus bas).
5. **Mettre à jour l'état de reprise** `ETAT_AUTO.md` : dernier prompt terminé,
   prochain prompt, compteur, heure.
6. **Vérifier la clôture atomique** avant toute continuation :

   ```bash
   python tools/verify_prompt_closure.py JARDINS-NNNN --current
   ```

   La commande doit retourner `CLOSURE_PASS`. Elle vérifie le statut du
   registre, la preuve, les livrables déclarés, la ligne du journal et la
   cohérence de `ETAT_AUTO.md` avec `next_allowed`. Si elle échoue, ne pas
   enchaîner : corriger la trace du prompt courant ou rendre `BLOCKED` si
   l'échec est réel.
7. **Lire le `next_allowed`** de la ligne courante dans le registre. C'est le
   seul successeur autorisé. Il ne se déduit pas, il se lit.
8. **Enchaîner immédiatement** sur ce prompt, sans demander d'accord, sans
   annoncer l'intention, sans attendre de réponse.

Puis recommencer en 1.

**L'arrêt n'est jamais la valeur par défaut.** Un prompt terminé en `PASS`
enchaîne. Toujours.

---

## Les seules raisons de s'arrêter

L'agent s'arrête **uniquement** dans ces cas, et écrit alors un bloc d'arrêt
(format plus bas) :

| Situation | Détail |
|---|---|
| **`BLOCKED`** | une dépendance manque, un canon produit par un domaine non exécuté est nécessaire |
| **Gate non validé après correction** | le gate reste `FAIL` après le passage par `05_CORRECTION` du domaine, deux tentatives au maximum |
| **Information indispensable manquante** | une valeur qui n'est ni dans la bible, ni dans le périmètre, ni dans un canon déjà produit |
| **Instructions en conflit** | deux documents gouvernants se contredisent sur le même point |
| **Décision qui appartient au propriétaire** | une quantité à trancher, un choix de conception, une orientation de contenu |
| **Erreur technique bloquante** | outil absent, moteur en échec, dépendance non installée, écriture impossible |
| **Le registre est incohérent** | `next_allowed` vide, inconnu, ou pointant vers un prompt déjà terminé |
| **Le successeur n'existe pas** | le fichier désigné par `relative_path` est introuvable |
| **Fin de chaîne** | `next_allowed` vaut `JARDINS_FINAL_GATE` : la chaîne est terminée, ce n'est pas un blocage |

**Interdiction formelle d'inventer pour continuer.** Devant l'une de ces
situations, s'arrêter est le comportement correct ; combler par une valeur
plausible est une faute. C'est exactement ainsi que la chaîne précédente a
produit une seule culture là où quarante étaient attendues.

---

## Ce qui n'est PAS une raison de s'arrêter

- Un `FAIL` au premier essai : la chaîne prévoit `05_CORRECTION` dans le
  domaine. On y va automatiquement, on corrige, on repasse le gate.
- Un doute esthétique, un choix de formulation, un détail de mise en forme :
  décider, noter la décision dans le journal, continuer.
- Un domaine long, une étape ennuyeuse, un grand nombre d'entrées à produire :
  le volume est le travail, pas un obstacle.
- Le sentiment d'avoir besoin d'un accord : le lancement initial **est**
  l'accord, pour toute la chaîne.
- **Une vérification non applicable à cette étape** : un test qui porte sur du
  code qu'un prompt ultérieur écrira. L'inscrire `NON APPLICABLE À CETTE ÉTAPE`
  au rapport, avec la raison, et continuer.
- **Un outil introuvable sous le nom attendu** : voir « Les outils requis » plus
  bas, utiliser le chemin réel. Un outil présent sous un autre nom n'est pas un
  outil manquant.
- **Un dossier ou un fichier absent que cette étape doit justement créer** :
  le créer est le travail, pas un obstacle. Le projet Godot cible n'existe pas
  au premier prompt : c'est `00_INITIALISATION` qui le crée.

**Avant tout arrêt, trois questions.** Si la réponse à l'une est oui, ce n'est
pas un blocage :

1. Est-ce que je peux le produire moi-même dans le cadre de cette étape ?
2. Est-ce qu'un prompt ultérieur de la chaîne est censé le produire ?
3. Est-ce que la chose existe ailleurs, sous un autre nom ou un autre chemin ?

Un arrêt coûte une intervention humaine. Il se justifie par une **impossibilité
réelle**, jamais par une gêne.

---

## Le journal — `docs/evidence/JOURNAL_AUTO.md`

Une ligne par prompt terminé, ajoutée immédiatement. C'est ce que le
propriétaire lira pour savoir ce qui s'est passé en son absence.

```
| heure | id | domaine/étape | gate | ce qui a été produit | compte |
```

Exemple :

```
| 22:41 | JARDINS-0031 | 04_BOOTSTRAP/02_IMPLEMENTATION | PASS | boot_flow.json | etapes=4 |
```

Toutes les **dix étapes**, ajouter un point d'étape : nombre de prompts
terminés, domaine en cours, décisions prises, écarts constatés. **Un point
d'étape ne s'arrête pas** — il s'écrit et la boucle continue.

---

## L'état de reprise — `ETAT_AUTO.md`

Un agent n'a pas une mémoire infinie : une longue exécution finit par saturer
son contexte, ou par être interrompue. Ce fichier existe pour que cela ne coûte
rien.

À réécrire après **chaque** prompt :

```markdown
# État de la boucle automatique

Dernier prompt terminé : JARDINS-0031 (PASS)
Prochain prompt        : JARDINS-0032 — 04_BOOTSTRAP_ET_DEMARRAGE/03_INTEGRATION.md
Terminés               : 31 / 406
Domaine en cours       : 04_BOOTSTRAP_ET_DEMARRAGE
Dernière écriture      : 2026-09-20 22:41
Décisions prises sans arbitrage : (liste courte, ou « aucune »)
```

Pour reprendre après une interruption, le propriétaire n'envoie qu'un mot :
**`reprends`**. L'agent lit `ETAT_AUTO.md`, relit les quatre documents
gouvernants, et repart à l'étape 1 de la boucle sur le prochain prompt. Aucun
travail n'est refait : un prompt déjà en `PASS` au registre ne se réexécute
jamais.

---

## Le bloc d'arrêt

Quand l'agent s'arrête, il écrit **exactement** ceci, et rien d'autre après :

```markdown
## ARRÊT — intervention nécessaire

**Prompt** : JARDINS-0187 — 15B_FACTIONS_ET_COMMERCE/02_IMPLEMENTATION.md
**Motif** : décision qui appartient au propriétaire
**Ce qui bloque** : le périmètre ne dit pas combien d'offres chaque marchand
propose ; six marchands et trente offres au total sont exigés, la répartition
n'est écrite nulle part.
**Ce que j'ai déjà fait** : les 4 factions et leurs 8 effets d'influence sont
produits et vérifiés ; seule la table des offres est en attente.
**Ce dont j'ai besoin de toi** : une seule réponse — répartition égale (5
chacun), ou répartition libre laissée à ma décision ?
**Reprise** : dès ta réponse, je repars de ce prompt et la boucle continue.
```

Une question **fermée**, une seule à la fois quand c'est possible, et l'état
exact du travail déjà fait. Pas de résumé général, pas de liste d'options
décoratives.

---

## Les garde-fous

Ils ne sont pas négociables, et l'automatisme ne les assouplit pas :

1. **Jamais deux prompts en parallèle.** La chaîne est un chemin unique.
2. **Jamais sauter un prompt**, même s'il paraît inutile ou déjà couvert.
3. **Jamais réexécuter** un prompt déjà en `PASS`.
4. **Jamais prononcer `PASS` sans preuve consultable** : un `PASS` non prouvé
   vaut `FAIL`, et la boucle ne doit pas avancer sur une preuve absente.
5. **Toujours exécuter `tools/verify_prompt_closure.py`** avec l'identifiant
   courant avant de lire `next_allowed` et de poursuivre. Un échec de cette
   clôture interdit l'enchaînement.
6. **Jamais inventer un nom** absent de `00_BIBLE_DU_JEU.md`.
7. **Jamais descendre sous les quantités** écrites dans le prompt.
8. **Relancer les trois audits** (`audit_chaine`, `audit_qualite_prompts`,
   `audit_livrables`) **à la fin de chaque domaine**, c'est-à-dire après chaque
   `06_GATE`. S'ils remontent un constat, le traiter avant de passer au domaine
   suivant — c'est un `FAIL` de domaine, pas un arrêt.
8. **Ne jamais modifier `tools/` de sa propre initiative.** Les outils d'audit
   sont les juges de la chaîne. Un agent qui assouplit son juge pour obtenir un
   vert a produit un vert qui ne veut plus rien dire — et c'est indétectable
   ensuite, parce que le contrôle qui aurait dû le voir est précisément celui
   qu'on a modifié.

   Si un outil produit un **faux positif** réel : ne pas le corriger en
   silence. S'arrêter, motif « décision qui appartient au propriétaire »,
   montrer la sortie fautive et la correction proposée. C'est le seul arrêt
   qui ne se discute pas.

   Un faux positif ne se reconnaît pas au fait qu'il gêne : il se reconnaît au
   fait que le contrôle affirme quelque chose de **faux**. « Ce domaine n'est
   pas encore exécuté » n'est pas un faux positif, c'est une information.

9. **Relire `00_CONTRAT_COMMUN.md` au début de chaque domaine.** Une boucle
   longue dérive ; la relecture est ce qui la ramène.

---

## Les outils requis, et ou ils sont

Avant de declarer un blocage technique sur un outil, **verifier ici** : il est
peut-etre installe sous un autre nom.

| Outil | Commande attendue | Sur cette machine |
|---|---|---|
| Godot | `godot` | `C:\Users\daric\AppData\Local\Microsoft\WinGet\Packages\GodotEngine.GodotEngine_Microsoft.Winget.Source_8wekyb3d8bbwe\Godot_v4.7.2-stable_win64_console.exe` (4.7.2) |
| Python | `python` | dans le PATH |
| Blender | `blender` | voir `_PIPELINE_BLENDER/GUIDE_OUTILS.md` |

Si `godot` n'est pas joignable sous ce nom, **utiliser le chemin complet
ci-dessus** au lieu de rendre `BLOCKED` : un outil present sous un autre nom
n'est pas un outil manquant. Utiliser la variante `_console.exe`, la seule qui
renvoie sa sortie en ligne de commande.

## Le lancement

Un seul message, une seule fois :

> Travaille dans `C:\Users\daric\OneDrive\Bureau\Prompts-Jardins-V4-AUTO`.
> Lis `00_MODE_AUTOMATIQUE.md`, `00_CONTRAT_COMMUN.md`, `00_BIBLE_DU_JEU.md` et
> `00_PERIMETRE_CONTENU.md`, puis exécute `00_INITIALISATION\00_CONTRAT.md`.
> **Applique le mode automatique** : enchaîne les prompts sans me demander
> d'accord, et ne t'arrête que sur un motif de la liste des arrêts.

Ensuite, ne rien envoyer. Lire `JOURNAL_AUTO.md` de temps en temps.
