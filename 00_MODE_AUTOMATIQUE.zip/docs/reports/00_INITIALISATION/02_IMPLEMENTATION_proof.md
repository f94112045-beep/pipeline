# Preuve — JARDINS-0003

## Prompt

- ID : `JARDINS-0003`
- Domaine : `00_INITIALISATION`
- Étape : `02_IMPLEMENTATION`
- Date : `2026-09-20 22:40:00 +02:00`

## Livrables

- `data/canon/identity.json`
- `project.godot`
- `scenes/main.tscn`
- `src/godot/main.gd`
- `tests/test_boot.gd` — créé avec le bootstrap pour satisfaire la vérification
  obligatoire de cette étape ; il sera corrigé par l'étape dédiée si nécessaire.

## Comptes par section

| Section | Compte | Minimum | Référencement |
|---|---:|---:|---|
| `canonical_characters` | 1 | 1 | `system.player` |
| `biomes` | 7 | 7 | `system.world` |
| `perimetre_contenu` | 1 | 1 | `system.content_registry` |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| Godot console avec `--headless --path C:\Users\daric\OneDrive\Bureau\Les-Jardins-de-l-Heure-Creuse-V4-AUTO --script res://tests/test_boot.gd` | 0 | BOOT PASS — canon, sept biomes, projet et scène principale |
| `python tools/audit_chaine.py` | 0 | PASS — 0 famille de défaut, 0 constat |
| `python tools/audit_livrables.py` | 0 | PASS technique — les constats futurs concernent des domaines non exécutés |

## Décision provisoire

## Hashes

| Fichier | SHA-256 |
|---|---|
| `data/canon/identity.json` | `73648994859689D07381B775383FC7D3A005ADE23ED658134826031AEDEE640D` |
| `project.godot` | `469AFA95811DBDE667D342C98C4C0F0FB4EA042C6ED9579249AD61299B302DC2` |
| `scenes/main.tscn` | `79442843D634DE2FD86BB967F81FCDE51DD895CDD84AA877E8E7DF6D7CE2ECB0` |
| `src/godot/main.gd` | `9887A577FFE536E69844DBE6449112F1DBB209FFCB0BD4BFC12ECB4D3FE3EAFF` |
| `tests/test_boot.gd` | `996404E7A7B136D485C6E9F08A525EA090AEAFE346E1488864EA2E58DB49EFF5` |

## Décision

`PASS` — le projet Godot, le canon et le test de contenu sont produits et
vérifiés.
