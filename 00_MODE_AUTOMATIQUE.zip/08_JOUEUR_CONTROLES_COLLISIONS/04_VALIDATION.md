<!-- ID: JARDINS-0061 -->
# 08_JOUEUR_CONTROLES_COLLISIONS — Validation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Le Semeur se deplace, interagit et se heurte au monde.

**Étape Validation :** Prouver que ca marche ET que c'est complet. Le test doit porter sur le CONTENU, pas seulement sur la mecanique.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/08_JOUEUR_CONTROLES_COLLISIONS/`.

## Canons lus en entrée

Ce domaine ne consomme aucun canon produit avant lui.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/camera.json` — produit plus tard par `09_CAMERA_ET_TRANSITIONS`
- `data/canon/world_architecture.json` — produit plus tard par `11_MONDE_ET_BIOMES`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/player_input.json` | `actions` | **8** |
| `data/canon/collision.json` | `couches` | **4** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Semeur**

## Système exigé : les gestes de service

Ils ne sont dans aucun concept parce qu'ils vont de soi — et c'est pour ça
qu'aucun domaine ne les produit. Chacun doit exister dans
`data/canon/player_input.json`, section `gestes_de_service` :

- **mettre en pause et revenir** : ce qui se fige, ce qui continue, ce que le
  joueur voit, et depuis quels contextes la pause est interdite (cinématique,
  transition) ;
- **annuler ou refuser** avant validation : quitter un dialogue, renoncer à une
  interaction, fermer un menu sans effet — avec la touche associée ;
- **attendre** sans dormir, si le joueur doit pouvoir laisser passer du temps.

Leur interface est produite par `10_MENUS_UX_ACCESSIBILITE` ; ce domaine produit
l'entrée et l'état.

## Fichiers exacts a modifier

- `tests/test_player_input.gd`
- `docs/reports/08_JOUEUR_CONTROLES_COLLISIONS/04_VALIDATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_player_input.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/08_JOUEUR_CONTROLES_COLLISIONS/04_VALIDATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0061-joueur_contr`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0061` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0061`
Domaine : `08_JOUEUR_CONTROLES_COLLISIONS`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
