# Preuve — JARDINS-0008

## Prompt

- ID : `JARDINS-0008`
- Domaine : `01_VERSIONNAGE_ET_ROLLBACK`
- Étape : `00_CONTRAT`
- Date : `2026-09-20 22:47:00 +02:00`

## Contrat établi

Le domaine installera le dépôt Git du projet cible, appliquera une branche par
prompt, produira un commit par étape utile et une étiquette `gate/<id>` après
chaque gate `PASS`. Le rollback sera prouvé par création, modification,
retour à l'étiquette, puis vérification du contenu restauré.

## Comptes par section

Ce domaine ne produit aucun canon chiffré. Les comptes de contenu du domaine
`00_INITIALISATION` restent : `canonical_characters=1`,
`biomes=7`, `perimetre_contenu=1`.

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| `python tools/audit_qualite_prompts.py` | à exécuter | audit qualité |
| `python tools/audit_chaine.py` | à exécuter | audit chaîne |
| `python tools/audit_livrables.py` | à exécuter | audit livrables |
| `git status --short --branch` | 128 | **NON APPLICABLE À CETTE ÉTAPE** — le dépôt est produit par `JARDINS-0010` |

## Hashes

| Fichier | SHA-256 |
|---|---|
| `01_VERSIONNAGE_ET_ROLLBACK/00_CONTRAT.md` | `F2EE8B2F316BB30A1B3290F139D9BD92A6745C2D222AC6AF621710A978C415CC` |

## Décision

`PASS` — contrat de versionnage établi ; la création du dépôt est réservée aux
étapes d'implémentation du domaine.
