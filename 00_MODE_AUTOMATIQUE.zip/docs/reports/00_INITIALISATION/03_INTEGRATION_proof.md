# Preuve — JARDINS-0004

## Prompt

- ID : `JARDINS-0004`
- Domaine : `00_INITIALISATION`
- Étape : `03_INTEGRATION`
- Date : `2026-09-20 22:42:00 +02:00`

## Intégration réalisée

La scène principale charge `src/godot/main.gd`; le script charge
`data/canon/identity.json`, vérifie `Nacreval` et les sept biomes, puis expose
`identity_loaded`. Le nœud `IdentityBootstrap` rend le branchement explicite
dans `scenes/main.tscn`.

## Comptes par section

| Section | Compte | Minimum |
|---|---:|---:|
| `canonical_characters` | 1 | 1 |
| `biomes` | 7 | 7 |
| `perimetre_contenu` | 1 | 1 |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| Godot console `--headless --path C:\Users\daric\OneDrive\Bureau\Les-Jardins-de-l-Heure-Creuse-V4-AUTO --script res://tests/test_boot.gd` | 0 | BOOT PASS |
| `python tools/audit_chaine.py` | 0 | PASS |
| `python tools/audit_livrables.py` | 0 | PASS technique ; constats futurs uniquement |

## Hashes

| Fichier | SHA-256 |
|---|---|
| `data/canon/identity.json` | `79442843D634DE2FD86BB967F81FCDE51DD895CDD84AA877E8E7DF6D7CE2ECB0` |
| `scenes/main.tscn` | `172DB3C626AE8C0552804F0F517AEA3F72E3F85D1431FF17B4560A75691C8A11` |
| `src/godot/main.gd` | `2337505175AD6864AAE425403D93D0B92B4C03125052165E10ED84EFC7ACBA08` |

## Décision

`PASS` — le canon d'identité est atteignable depuis la scène principale et le
bootstrap valide son contenu canonique.
