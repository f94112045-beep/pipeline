<!-- ID: JARDINS-0274 -->
# JARDINS-0274 — Production Visuelle 3D de l'Objet : Craie de Passage

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Produire l'asset visuel 3D Blender **dédié et unique** pour l'objet canonique **Craie de Passage** (`PROP_CRAIE_DE_PASSAGE`).

- **Prompt ID** : `JARDINS-0274`
- **Asset ID** : `PROP_CRAIE_DE_PASSAGE`
- **Nom canonique** : `Craie de Passage`
- **Catégorie** : `talisman`
- **Canon source** : `data/canon/objects_economy.json#objet_craie_de_passage`

## Ce que ce prompt doit livrer
1. Un script Python Blender 3D DÉDIÉ et UNIQUE : `_PIPELINE_BLENDER/builders/props/PROP_CRAIE_DE_PASSAGE.py`. (Tout builder partagé ou générique est STRICTEMENT INTERDIT).
2. Une fiche de configuration JSON : `_PIPELINE_BLENDER/fiches/PROP_CRAIE_DE_PASSAGE.json` pointant vers son builder dédié.
3. Le rendu du fichier PNG de l'asset dans `assets/generated/props/PROP_CRAIE_DE_PASSAGE.png`.

## Consignes Obligatoires
1. **Règle du Builder Dédié Unique** : Écris la géométrie 3D Blender spécifique pour l'anatomie réelle de l'objet **Craie de Passage**. L'objet doit comporter ses composants 3D réels (ex: manche, goulot, lame, reliure, dôme, buse, charnière, ornements) et être immédiatement reconnaissable.
2. **Fond Transparent & Zéro Socle** : Centré sur fond transparent sans aucun socle ni boîte parasite au sol.
3. **Inspection Visuelle Individuelle** : Ouvre le PNG rendu avec tes outils de vision, effectue les 3 Passes d'audit visuel (Anatomie, Esthétique Pixel Art, Unicité), et consigne le résultat avant d'accorder PASS.

## Lecture obligatoire
1. `../00_CONTRAT_COMMUN.md` — règles universelles de la chaîne ;
2. `../00_BIBLE_DU_JEU.md` — source de vérité narrative ;
3. `data/canon/objects_economy.json` — canon d'entrée des objets.

## Décision

Rendre PASS si le prompt a réussi. Sinon rendre FAIL ou BLOCKED.


## Procedure de Rollback Git
Si échec, exécuter `git reset --hard` et supprimer la branche temporaire.
