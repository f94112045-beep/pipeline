# Preuve — JARDINS-0009

## Prompt

- ID : `JARDINS-0009`
- Domaine : `01_VERSIONNAGE_ET_ROLLBACK`
- Étape : `01_DESIGN`
- Date : `2026-09-20 22:48:00 +02:00`

## Conception arrêtée

Le dépôt Git sera créé à la racine du projet cible par `JARDINS-0010`.
Chaque prompt utile sera isolé sur une branche `rebuild/<id>-<mot-clef>`,
chaque étape utile sera commitée avec son identifiant, et chaque gate validé
recevra une étiquette `gate/<id>`. Les fichiers générés, rendus
intermédiaires, caches et `.godot/` seront exclus par `.gitignore`.

Le rollback sera testé sur une modification réversible d'un fichier suivi :
commit de référence, modification, commit, retour à l'étiquette et vérification
du contenu restauré.

## Comptes

Ce domaine ne produit aucun canon chiffré à l'étape design.

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| `python tools/audit_qualite_prompts.py` | 0 | PASS |
| `python tools/audit_chaine.py` | 0 | PASS |
| `python tools/audit_livrables.py` | 0 | PASS |
| Vérification Git | — | **NON APPLICABLE À CETTE ÉTAPE** — dépôt produit à `JARDINS-0010` |

## Hashes

| Fichier | SHA-256 |
|---|---|
| `01_VERSIONNAGE_ET_ROLLBACK/01_DESIGN.md` | `D9479D63D9429BF8A56C84B29F2395756248E407E3605E3F631C502AB6DF2D89` |

## Décision

`PASS` — conception du versionnage et du rollback complète, sans production
à cette étape.
