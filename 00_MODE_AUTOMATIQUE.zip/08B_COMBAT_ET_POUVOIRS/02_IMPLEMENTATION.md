<!-- ID: JARDINS-0066 -->
# 08B_COMBAT_ET_POUVOIRS — Implementation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Le combat reste lisible et rapide : une arme principale, un outil secondaire, un pouvoir memoriel, une esquive. Les pouvoirs ne servent pas qu'a infliger des degats -- ils font oublier une attaque, figent un comportement, attirent une creature vers un souvenir, divisent une menace en emotions, ou retournent une capacite contre son origine.

**Étape Implementation :** Produire le contenu reel. C'est l'etape ou les quantites doivent etre atteintes.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 378 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/08B_COMBAT_ET_POUVOIRS/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/player_input.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/progression.json` — produit plus tard par `18_QUETES_ET_PROGRESSION`
- `data/canon/creatures.json` — produit plus tard par `21_CREATURES_ET_BOSS`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/combat.json` | `actions` | **6** |
| `data/canon/combat.json` | `pouvoirs_memoriels` | **5** |
| `data/canon/combat.json` | `styles_de_jeu` | **5** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Inventaire nominatif — ce qui doit exister, nommement

**Les quatre emplacements du joueur :** arme principale · outil secondaire ·
pouvoir memoriel · esquive ou mouvement defensif.

**Les cinq pouvoirs memoriels de la bible**, qui ne sont pas des degats :

1. faire **oublier une attaque** a un ennemi ;
2. **figer** un comportement ;
3. **attirer** une creature vers un souvenir ;
4. **diviser** une menace en plusieurs emotions ;
5. **retourner** une capacite contre son origine.

**Les cinq styles de jeu doivent rester viables** : combattant direct ·
explorateur prudent · jardinier qui utilise le terrain · mediateur qui evite les
affrontements · specialiste des creatures.

Le mediateur est la charniere avec `22_SOLUTIONS_NON_VIOLENTES` : chaque
creature doit avoir une issue sans combat.

Un compte protege du vide ; il ne protege pas de l'oubli.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Secateur d'Instants**

## Fichiers exacts a modifier

- `data/canon/combat.json` — **ce prompt en est le producteur**
- `src/godot/combat.gd`
- `docs/reports/08B_COMBAT_ET_POUVOIRS/02_IMPLEMENTATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_combat.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/08B_COMBAT_ET_POUVOIRS/02_IMPLEMENTATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0066-combat_et_po`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0066` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0066`
Domaine : `08B_COMBAT_ET_POUVOIRS`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
