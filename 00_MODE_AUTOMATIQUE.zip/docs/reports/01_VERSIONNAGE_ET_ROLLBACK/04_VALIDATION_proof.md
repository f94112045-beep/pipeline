# Preuve — JARDINS-0012

## Prompt

- ID : `JARDINS-0012`
- Domaine : `01_VERSIONNAGE_ET_ROLLBACK`
- Étape : `04_VALIDATION`
- Date : `2026-09-20 22:54:00 +02:00`

## Test de rollback

Le hash de `.gitignore` avant modification était
`962586ABD1A3CAEBE133D01F6B5F8A4B413DE4BD75DB4003AB24ADD52B11C643`.
Après ajout d'une donnée temporaire, le hash est devenu
`2E80EB640F5D8445136A38673EC574F75803A8C876CD7961B3DE7C492F496529`.
La commande `git restore --source gate/JARDINS-0011 -- .gitignore` a restauré
le hash initial.

## Comptes

| Section | Compte | Minimum |
|---|---:|---:|
| tags de gate | 2 | 1 |
| branches de prompt | 3 | 1 |
| fichiers de convention | 2 | 2 |
| rollback vérifié | 1 | 1 |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| test `git restore` avec comparaison de hashes | 0 | `ROLLBACK_PASS` |
| `python tools/audit_qualite_prompts.py` | 0 | 0 constat |
| `python tools/audit_chaine.py` | 0 | 0 constat |
| `python tools/audit_livrables.py` | 0 | 0 constat |

## Hashes

| Élément | Valeur |
|---|---|
| `.gitignore` restauré | `962586ABD1A3CAEBE133D01F6B5F8A4B413DE4BD75DB4003AB24ADD52B11C643` |
| tag `gate/JARDINS-0010` | `729a7c7effd39442470647c3922a8a86ebda2a27` |
| tag `gate/JARDINS-0011` | `1605a50` |

## Décision

`PASS` — le rollback Git restaure effectivement le contenu depuis une
étiquette de gate.
