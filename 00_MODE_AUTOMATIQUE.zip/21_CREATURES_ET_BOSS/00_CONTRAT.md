<!-- ID: JARDINS-0183 -->
# 21_CREATURES_ET_BOSS — Contrat

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Les QUATRE familles de creatures et les QUATRE boss de la bible, chacun avec plusieurs solutions possibles.

**Étape Contrat :** Etablir le contrat du domaine : ce qui sera produit, en quelle quantite, avec quelles entrees et quelles preuves. AUCUNE production a cette etape.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/21_CREATURES_ET_BOSS/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/world_states.json`
- `data/canon/inventory.json`
- `data/canon/world_architecture.json`
- `data/canon/combat.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/creatures.json` | `familles` | **4** |
| `data/canon/creatures.json` | `creatures` | **20** |
| `data/canon/creatures.json` | `boss` | **4** |
| `data/canon/creatures.json` | `dangers_environnementaux` | **5** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Effacés**
- **Contradictions**
- **Mues**
- **Mange-Temps**
- **Cerf des Cent Departs**
- **Reine des Chambres**
- **Geant Sans Hier**
- **Horloger Inverse**


## Système exigé : la perception sonore

La bible dit des Falaises de Verre Mat : « **les ennemis réagissent aux sons
produits par le joueur** ». Ce n'est pas de la couleur locale, c'est un système.

Produire dans `data/canon/creatures.json` une section `perception` :

- ce qui fait du **bruit** côté joueur (marche, course, outil, combat, chute) et
  le rayon associé ;
- comment une créature **entend**, **cherche**, puis **perd** la trace ;
- quelles créatures y sont sensibles, et lesquelles ne le sont pas ;
- comment le joueur peut se faire **discret**.

Sans ce système, les Falaises ne sont qu'un biome de plus avec une autre palette.

## Système exigé : les Mues et l'émotion dominante

La bible dit : « **les Mues changent de forme selon l'émotion dominante du
joueur** ». Cela suppose un **état émotionnel du joueur**, produit par
`05_MODELE_CANONIQUE_ET_ETATS`. Ce domaine le **consomme** : il déclare, pour
chaque émotion, la forme prise par la Mue et son comportement.

Si l'état émotionnel n'existe pas encore, rendre `BLOCKED` en nommant
`05_MODELE_CANONIQUE_ET_ETATS`. Ne pas l'inventer ici.

## Système exigé : l'attraction par les souvenirs portés

La bible dit du Désert des Heures Blanches que les créatures y sont attirées par
ceux qui portent trop de souvenirs. C'est une mécanique de tension : plus le
joueur a récolté, plus le retour est risqué.

Dans `data/canon/creatures.json`, section `attraction` : le **seuil** de
souvenirs portés à partir duquel l'attraction commence, comment elle monte,
quelles créatures y sont sensibles, comment le joueur la **voit venir**, et
comment il la réduit — déposer, cacher, emprunter un autre chemin.

Consomme l'inventaire de souvenirs (`14_RESSOURCES_INVENTAIRE_CRAFT`).

## Système exigé : l'effet temporel des Mange-Temps

La bible dit qu'ils accélèrent ou ralentissent les activités. Ce n'est pas un
dégât, c'est un modificateur de temps.

Dans `data/canon/creatures.json`, section `distorsion_temporelle` : ce qui est
affecté (croissance des cultures, vitesse de déplacement, durée d'un outil,
avancée de l'horloge), l'amplitude chiffrée, la durée, si c'est subi ou
exploitable par le joueur, et comment il le perçoit.

Une créature qui ralentit le joueur sans qu'il comprenne pourquoi est un bug
pour lui, pas une mécanique.

## Fichiers exacts a modifier

- `docs/reports/21_CREATURES_ET_BOSS/00_CONTRAT_proof.md`

## Vérification

```bash
# (le test Godot n'est PAS exige a cette etape : elle ne produit aucun
#  code. Il devient obligatoire des `02_IMPLEMENTATION`.)
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/21_CREATURES_ET_BOSS/00_CONTRAT_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0183-creatures_et`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0183` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0183`
Domaine : `21_CREATURES_ET_BOSS`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
