<!-- ID: JARDINS-0318 -->
# 29_PERSONNAGES_SPRITES — Validation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Le Semeur et les 14 PNJ, 4 directions chacun.

**Étape Validation :** Prouver que ca marche ET que c'est complet. Le test doit porter sur le CONTENU, pas seulement sur la mecanique.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/29_PERSONNAGES_SPRITES/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/casting.json`
- `data/canon/npc_life.json`
- `data/canon/factions.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/characters_manifest.json` | `sprites` | **240** |

**Unité de comptage.** `characters_manifest.json`, section `sprites`, compte des **images**, pas des sujets : 15 personnages x 4 directions x 4 images. Un manifeste qui liste 15 entrees n'a pas rempli le contrat.

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.


## Inventaire nominatif — ce qui doit exister, nommement

**Le Semeur et les 14 PNJ, en 4 directions chacun** (Sud, Est, Nord, Ouest),
avec la meme boite et la meme palette sur toute la sequence.

Nommement, les cinq personnages canoniques : **Maelis**, **Orven**, **Siva**,
**Brel**, **Aune** — plus les neuf du casting etendu.

Rappel du moteur : on fait tourner **le sujet**, jamais la camera. La lumiere doit
rester constante dans l'espace de l'ecran.

Un compte protege du vide ; il ne protege pas de l'oubli. Chaque entree de cette liste doit se retrouver dans le manifeste du domaine, et le rapport de gate doit le montrer.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Semeur**
- **Maelis**
- **Orven**
- **Siva**
- **Brel**
- **Aune**


## Production d'assets — moteur obligatoire

Les images passent par le moteur Blender du projet :

```bash
python ../_PIPELINE_BLENDER/build_asset.py --fiche ../_PIPELINE_BLENDER/fiches/<ASSET_ID>.json
```

**Lecture obligatoire avant de produire :**
`../_PIPELINE_BLENDER/GUIDE_OUTILS.md` (quel outil pour quel besoin, et lequel
n'est pas Blender) et `../_PIPELINE_BLENDER/art_direction.json` (le canon :
palette, caméra, lumière, résolution, budgets).

Si l'asset visé n'a pas encore de builder, écrire d'abord le builder en suivant
`../_PIPELINE_BLENDER/GUIDE_ECRIRE_UN_BUILDER.md`.

`BLOCKED` n'est pas un échec : c'est le moteur qui refuse de produire un asset
faux. Corriger la cause nommée, jamais contourner le contrôle.

## Précontrôle obligatoire — les sorties réelles

**À lancer avant de prononcer le gate :**

```bash
python tools/precontrole_domaine.py 29_PERSONNAGES_SPRITES --sorties
```

Il doit afficher `PRECONTROLE_PASS`. En plus des sept vérifications amont, il
contrôle **ce qui a réellement été produit** : les images existent, le format
final est celui qu'attendent les tests, et le manifeste atteint son minimum.

Pour le terrain, cela signifie sept dossiers de tuiles portant chacun un vrai
`tileset.json` en convention `blob47` avec ses **47 configurations** — pas un
manifeste qui les résume.

Un `PASS` prononcé pendant que cette commande refuse vaut `FAIL`.

## Fichiers exacts a modifier

- `docs/reports/29_PERSONNAGES_SPRITES/04_VALIDATION_proof.md`

## Vérification

```bash
python tools/audit_qualite_prompts.py
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/29_PERSONNAGES_SPRITES/04_VALIDATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0318-personnages_`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0318` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0318`
Domaine : `29_PERSONNAGES_SPRITES`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
