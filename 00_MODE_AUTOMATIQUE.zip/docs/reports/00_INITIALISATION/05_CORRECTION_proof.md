# Preuve — JARDINS-0006

## Prompt

- ID : `JARDINS-0006`
- Domaine : `00_INITIALISATION`
- Étape : `05_CORRECTION`
- Date : `2026-09-20 22:44:00 +02:00`

## Correction réalisée

Le test de bootstrap couvre désormais explicitement les quatre entités
obligatoires de l'initialisation : `Nacreval`, `La Grande Déliaison`,
`La Maison-Pépinière` et `Les Graines d'Instant`. Les erreurs de canon absent,
JSON invalide et structure incomplète restent bloquantes avec un code non nul.

## Comptes par section

| Section | Compte | Minimum |
|---|---:|---:|
| `canonical_characters` | 1 | 1 |
| `biomes` | 7 | 7 |
| `perimetre_contenu` | 1 | 1 |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| Godot console `--headless --path C:\Users\daric\OneDrive\Bureau\Les-Jardins-de-l-Heure-Creuse-V4-AUTO --script res://tests/test_boot.gd` | 0 | BOOT PASS |
| `python tools/audit_chaine.py` | 0 | PASS |
| `python tools/audit_livrables.py` | 0 | PASS technique ; constats futurs uniquement |

## Hashes

| Fichier | SHA-256 |
|---|---|
| `tests/test_boot.gd` | `FED445C827D4212B54C1F5B536365C7DFD9ED2CF2DDFEA9C5A59D4E086272FFE` |

## Décision

`PASS` — la correction est validée.
