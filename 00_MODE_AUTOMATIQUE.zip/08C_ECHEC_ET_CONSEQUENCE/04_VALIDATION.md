<!-- ID: JARDINS-0075 -->
# 08C_ECHEC_ET_CONSEQUENCE — Validation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Le Semeur ne meurt pas. Quand il echoue, il se reveille a la Maison-Pepiniere, la journee a avance, et il a PERDU quelque chose de thematique : une partie de ce qu'il portait, ou un souvenir recent. L'echec coute, il n'interrompt pas.

**Étape Validation :** Prouver que ca marche ET que c'est complet. Le test doit porter sur le CONTENU, pas seulement sur la mecanique.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/08C_ECHEC_ET_CONSEQUENCE/`.

## Canons lus en entrée

Ce domaine ne consomme aucun canon produit avant lui.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/inventory.json` — produit plus tard par `14_RESSOURCES_INVENTAIRE_CRAFT`
- `data/canon/world_architecture.json` — produit plus tard par `11_MONDE_ET_BIOMES`
- `data/canon/daily_loop.json` — produit plus tard par `20B_BOUCLE_QUOTIDIENNE`
- `data/canon/creatures.json` — produit plus tard par `21_CREATURES_ET_BOSS`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/echec.json` | `causes_d_echec` | **5** |
| `data/canon/echec.json` | `pertes_possibles` | **6** |
| `data/canon/echec.json` | `retours_au_refuge` | **2** |
| `data/canon/echec.json` | `protections` | **3** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Inventaire nominatif — ce qui doit exister, nommement

**Il n'y a ni ecran de game over, ni rechargement force.** C'est une decision
de conception : la dire explicitement empeche chaque domaine d'improviser sa
propre defaite.

- **Cinq causes d'echec** au minimum : creature, danger environnemental, nuit
  passee dehors, anomalie temporelle, epuisement.
- **Six pertes possibles**, toutes thematiques et reversibles autrement :
  une partie du sac, un souvenir recent non depose, une journee, la fraicheur
  d'une recolte, un lien fragile avec un PNJ, une graine en cours.
  **Jamais une progression definitive.**
- **Le retour** : ou, dans quel etat, avec quelle mise en scene, et ce que le
  joueur comprend de ce qu'il a perdu -- une perte invisible n'apprend rien.
- **Trois protections** : ce qui ne peut jamais etre perdu (le Carnet des
  Continuites, les batiments, les relations acquises).

Les **Effacés** devorent les souvenirs recents : ils sont la cause d'echec la
plus alignee avec le theme. Ce domaine dit ce qu'ils prennent exactement.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Maison-Pepiniere**
- **Graines d'Instant**
- **Effacés**

## Fichiers exacts a modifier

- `tests/test_echec.gd`
- `docs/reports/08C_ECHEC_ET_CONSEQUENCE/04_VALIDATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_echec.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/08C_ECHEC_ET_CONSEQUENCE/04_VALIDATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0075-echec_et_con`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0075` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0075`
Domaine : `08C_ECHEC_ET_CONSEQUENCE`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
