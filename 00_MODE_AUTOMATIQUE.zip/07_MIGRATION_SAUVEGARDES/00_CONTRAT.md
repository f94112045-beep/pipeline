# 07_MIGRATION_SAUVEGARDES — Contrat

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Garantir qu'une partie enregistree avec un ancien format continue de s'ouvrir. Le seul bug qu'un joueur ne pardonne jamais.

**Étape Contrat :** Etablir le contrat du domaine : ce qui sera produit, en quelle quantite, avec quelles entrees et quelles preuves. AUCUNE production a cette etape.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/07_MIGRATION_SAUVEGARDES/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/save_contract.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/save_migration_contract.json` | `versions_supportees` | **3** |
| `data/canon/save_migration_contract.json` | `etapes` | **2** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ce domaine ne cree aucune entite nommee. Il ne doit donc en inventer aucune.

## Système exigé : migration des six états récents

Les six états nommés par `06_SAUVEGARDE_ET_CONFIGURATION`
(`emotion_joueur`, `influence_factions`, `etats_de_vie_pnj`, `carte_decouverte`,
`noms_de_plantes`, `consequences_differees`) ont été ajoutés après la première
version du format. Une sauvegarde ancienne ne les contient pas.

Pour chacun, la chaîne de migration doit dire **quelle valeur est écrite quand
le champ est absent** — et cette valeur doit être jouable, pas nulle : une carte
vide oblige à tout réexplorer, une influence nulle ferme des quartiers déjà
ouverts.

Test exigé : charger une sauvegarde de version antérieure, vérifier que les six
champs existent après migration, et que la partie reste cohérente.

## Fichiers exacts a modifier

- `docs/reports/07_MIGRATION_SAUVEGARDES/00_CONTRAT_proof.md`

## Vérification

```bash
# (le test Godot n'est PAS exige a cette etape : elle ne produit aucun
#  code. Il devient obligatoire des `02_IMPLEMENTATION`.)
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/07_MIGRATION_SAUVEGARDES/00_CONTRAT_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0050-migration_sa`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0050` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0050`
Domaine : `07_MIGRATION_SAUVEGARDES`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
