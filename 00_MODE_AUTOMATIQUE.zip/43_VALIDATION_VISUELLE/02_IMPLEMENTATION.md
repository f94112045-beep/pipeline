<!-- ID: JARDINS-0414 -->
# 43_VALIDATION_VISUELLE — Implementation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Captures depuis le renderer, baselines et seuils.

**Étape Implementation :** Produire le contenu reel. C'est l'etape ou les quantites doivent etre atteintes.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/43_VALIDATION_VISUELLE/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/asset_manifest.json`
- `data/canon/characters_manifest.json`
- `data/canon/creatures_manifest.json`
- `data/canon/ui_manifest.json`
- `data/canon/props_manifest.json`
- `data/canon/terrain_manifest.json`
- `data/canon/vegetation_manifest.json`
- `data/canon/buildings_manifest.json`
- `data/canon/portraits_manifest.json`
- `data/canon/effects_manifest.json`
- `data/canon/visual_profile.json`
- `data/canon/player_anim.json`
- `data/canon/npc_anim.json`
- `data/canon/world_anim.json`
- `data/canon/event_anim.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/visual_baselines.json` | `baselines` | **10** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ce domaine ne cree aucune entite nommee. Il ne doit donc en inventer aucune.


## Production d'assets — moteur obligatoire

Les images passent par le moteur Blender du projet :

```bash
python ../_PIPELINE_BLENDER/build_asset.py --fiche ../_PIPELINE_BLENDER/fiches/<ASSET_ID>.json
```

**Lecture obligatoire avant de produire :**
`../_PIPELINE_BLENDER/GUIDE_OUTILS.md` (quel outil pour quel besoin, et lequel
n'est pas Blender) et `../_PIPELINE_BLENDER/art_direction.json` (le canon :
palette, caméra, lumière, résolution, budgets).

Si l'asset visé n'a pas encore de builder, écrire d'abord le builder en suivant
`../_PIPELINE_BLENDER/GUIDE_ECRIRE_UN_BUILDER.md`.

`BLOCKED` n'est pas un échec : c'est le moteur qui refuse de produire un asset
faux. Corriger la cause nommée, jamais contourner le contrôle.

## Fichiers exacts a modifier

- `data/canon/visual_baselines.json` — **ce prompt en est le producteur**
- `docs/reports/43_VALIDATION_VISUELLE/02_IMPLEMENTATION_proof.md`

## Vérification

```bash
python tools/audit_qualite_prompts.py
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/43_VALIDATION_VISUELLE/02_IMPLEMENTATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0414-validation_v`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0414` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0414`
Domaine : `43_VALIDATION_VISUELLE`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
