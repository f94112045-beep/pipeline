# Preuve — JARDINS-0001

## Prompt

- ID : `JARDINS-0001`
- Domaine : `00_INITIALISATION`
- Étape : `00_CONTRAT`
- Date : `2026-09-20 22:38:49 +02:00`

## Vérifications exécutées

| Commande | Code retour | Résultat |
|---|---:|---|
| `python tools/audit_chaine.py` | 0 | PASS — chaîne cohérente |
| `python tools/audit_livrables.py` | 0 | PASS — projet cible absent, contrôle non applicable à cette étape de contrat |
| `python tools/audit_chaine.py` | 0 | PASS — 0 famille de défaut, 0 constat |
| `python tools/audit_livrables.py` | 0 | PASS technique — le projet cible n'existe pas encore ; aucun livrable réel auditable |

## Comptes par section

Cette étape est un contrat et ne produit volontairement aucune donnée de jeu.

| Livrable attendu à l'issue de la chaîne | Section | Minimum | Produit à cette étape |
|---|---|---:|---:|
| `data/canon/identity.json` | `canonical_characters` | 1 | 0 — production interdite à l'étape contrat |
| `data/canon/identity.json` | `biomes` | 7 | 0 — production interdite à l'étape contrat |
| `data/canon/identity.json` | `perimetre_contenu` | 1 | 0 — production interdite à l'étape contrat |

## Décision

`PASS` — cette étape de contrat ne produit ni code ni projet Godot. Le test
Godot est donc **NON APPLICABLE À CETTE ÉTAPE** ; le projet cible et le script
seront produits par les étapes d'implémentation et de correction. Les audits
applicables sont passés.

## Hashes

| Entrée | SHA-256 |
|---|---|
| `00_INITIALISATION/00_CONTRAT.md` | `9818E28F2650A61660B2D0F93FD177B4EE6B27D200D34F58DDA1706497E80BF2` |
| `00_BIBLE_DU_JEU.md` | `D208017F3C1DD227F49E85379DB7F7F905ED848FB950B9A354A8C9EE0862321C` |
| `00_PERIMETRE_CONTENU.md` | `9C454EFA815469CEA35F53DD5696B40A1F443E905D925F303139068E6679D86F` |
