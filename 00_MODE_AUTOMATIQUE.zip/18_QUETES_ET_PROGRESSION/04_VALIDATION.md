<!-- ID: JARDINS-0159 -->
# 18_QUETES_ET_PROGRESSION — Validation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Les quetes, et les trois voies de progression de la bible.

**Étape Validation :** Prouver que ca marche ET que c'est complet. Le test doit porter sur le CONTENU, pas seulement sur la mecanique.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/18_QUETES_ET_PROGRESSION/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/casting.json`
- `data/canon/cultures_craft.json`
- `data/canon/npc_life.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/exploration.json` — produit plus tard par `19_EXPLORATION_ET_ANOMALIES`
- `data/canon/narrative.json` — produit plus tard par `23_NARRATION_MYSTERE_FINS`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/quests.json` | `quetes` | **45** |
| `data/canon/quests.json` | `recompenses` | **45** |
| `data/canon/progression.json` | `voies` | **3** |
| `data/canon/progression.json` | `competences` | **15** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Jardinage**
- **Accordage**
- **Traversee**
- **Carnet des Continuites**

## Système exigé : les capacités des trois voies agissent en jeu

« Trois voies, quinze compétences » est un compte : il est satisfait par quinze
lignes de texte sans effet. Ce domaine doit produire, pour **chaque** compétence
des voies du Jardinage, de l'Accordage et de la Traversée :

- le **verbe** qu'elle ajoute ou modifie ;
- son **effet mesurable en jeu**, chiffré ;
- le **domaine qui l'exécute** — une compétence sans exécutant n'existe pas ;
- ce qui change **visiblement** pour le joueur quand il l'obtient.

Ce que la bible promet, et qui doit se retrouver ligne par ligne : faire pousser
des plantes rares, greffer deux souvenirs, modifier la météo locale (Jardinage) ·
entendre les émotions cachées, décoder les conversations anciennes, révéler les
mensonges (Accordage) · se déplacer sur les parois, résister aux anomalies
temporelles, transporter davantage de souvenirs (Traversée).

Une compétence dont l'effet est « améliore la progression » rend `FAIL`.

## Fichiers exacts a modifier

- `tests/test_quests.gd`
- `docs/reports/18_QUETES_ET_PROGRESSION/04_VALIDATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_quests.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/18_QUETES_ET_PROGRESSION/04_VALIDATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0159-quetes_et_pr`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0159` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0159`
Domaine : `18_QUETES_ET_PROGRESSION`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
