<!-- ID: JARDINS-0137 -->
# 15B_FACTIONS_ET_COMMERCE — Integration

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

La Cite Suspendue de Rive-Haute vit de luttes entre plusieurs visions du passe : commerce, politique, intrigues, et des batiments qui se deplacent quand une faction gagne en influence. Sans systeme de factions, la Cite n'est qu'un decor de plus.

**Étape Integration :** Brancher ce qui vient d'etre produit sur le jeu reel : scenes, systemes, declencheurs. Un contenu non atteignable en jeu n'existe pas.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 392 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/15B_FACTIONS_ET_COMMERCE/`.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/factions.json` | `factions` | **4** |
| `data/canon/factions.json` | `relations_inter_factions` | **6** |
| `data/canon/factions.json` | `effets_d_influence` | **8** |
| `data/canon/commerce.json` | `marchands` | **6** |
| `data/canon/commerce.json` | `offres` | **30** |
| `data/canon/commerce.json` | `taux_par_faction` | **4** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Cite Suspendue de Rive-Haute**
- **Marche des Possibles**

## Fichiers exacts a modifier

- `src/godot/factions.gd`
- `src/godot/commerce.gd`
- `docs/reports/15B_FACTIONS_ET_COMMERCE/03_INTEGRATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_factions_commerce.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/15B_FACTIONS_ET_COMMERCE/03_INTEGRATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0137-factions_et_`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0137` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0137`
Domaine : `15B_FACTIONS_ET_COMMERCE`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
