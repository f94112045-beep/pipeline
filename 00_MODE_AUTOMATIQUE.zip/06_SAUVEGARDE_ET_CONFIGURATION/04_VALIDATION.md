# 06_SAUVEGARDE_ET_CONFIGURATION — Validation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Sauvegarder, recharger, et ne jamais perdre une partie.

**Étape Validation :** Prouver que ca marche ET que c'est complet. Le test doit porter sur le CONTENU, pas seulement sur la mecanique.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/06_SAUVEGARDE_ET_CONFIGURATION/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/world_states.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/factions.json` — produit plus tard par `15B_FACTIONS_ET_COMMERCE`
- `data/canon/npc_life.json` — produit plus tard par `17_PNJ_HORAIRES_RELATIONS_DIALOGUES`
- `data/canon/exploration.json` — produit plus tard par `19_EXPLORATION_ET_ANOMALIES`
- `data/canon/cultures_craft.json` — produit plus tard par `13_CULTURES_JARDINAGE_SAISONS`
- `data/canon/daily_loop.json` — produit plus tard par `20B_BOUCLE_QUOTIDIENNE`
- `data/canon/inventory.json` — produit plus tard par `14_RESSOURCES_INVENTAIRE_CRAFT`
- `data/canon/quests.json` — produit plus tard par `18_QUETES_ET_PROGRESSION`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/save_contract.json` | `champs_critiques` | **11** |
| `data/canon/save_contract.json` | `champs_derives` | **2** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ce domaine ne cree aucune entite nommee. Il ne doit donc en inventer aucune.

## Système exigé : le registre nominatif des états sauvegardés

Six domaines déclarent chacun de leur côté qu'un état est « persistant en
sauvegarde ». Ce domaine est le seul qui puisse le rendre vrai : **un état que
ce contrat ne nomme pas n'est pas sauvegardé**, quoi qu'en dise le domaine qui
le produit.

`data/canon/save_contract.json`, section `champs_critiques`, doit nommer
**explicitement, un par un**, au minimum ces six états, en plus des états de
base (position, temps, inventaire, quêtes, relations) :

| Champ | Produit par | Ce qui est perdu s'il manque |
|---|---|---|
| `emotion_joueur` | `05_MODELE_CANONIQUE_ET_ETATS` | la forme des Mues redevient aléatoire |
| `influence_factions` | `15B_FACTIONS_ET_COMMERCE` | les quartiers et les prix se réinitialisent |
| `etats_de_vie_pnj` | `17_PNJ_HORAIRES_RELATIONS_DIALOGUES` | un PNJ qui avait changé de métier redevient celui du début |
| `carte_decouverte` | `19_EXPLORATION_ET_ANOMALIES` | le joueur re-explore une carte qu'il connaît |
| `noms_de_plantes` | `13_CULTURES_JARDINAGE_SAISONS` | les propriétés acquises par le nommage disparaissent |
| `consequences_differees` | `20B_BOUCLE_QUOTIDIENNE` | une décision prise hier ne se réalise jamais |
| `stockage_refuge` | `14_RESSOURCES_INVENTAIRE_CRAFT` | tout ce que le joueur avait mis de côté |

Pour chacun : son type, sa valeur par défaut à la première partie, et le test
qui prouve l'aller-retour sauvegarde → rechargement.

**La règle générale, à écrire dans le contrat :** tout domaine qui déclare un
état persistant doit être référencé ici. Si un domaine non encore exécuté en
annonce un, rendre `BLOCKED` en le nommant plutôt que de l'omettre.

## Système exigé : la sauvegarde volontaire

`20B_BOUCLE_QUOTIDIENNE` produit la sauvegarde automatique au coucher. Il manque
le geste du joueur qui veut sauvegarder **maintenant**, avant de fermer le jeu.

Dans `data/canon/save_contract.json`, section `sauvegarde_volontaire` : d'où
elle se déclenche, ce qu'elle écrit, quand elle est refusée (en plein événement,
en plein combat), et le retour visible qui confirme au joueur que c'est fait.
Sans confirmation, il refermera le jeu en doutant.

## Fichiers exacts a modifier

- `tests/test_save_load.gd`
- `docs/reports/06_SAUVEGARDE_ET_CONFIGURATION/04_VALIDATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_save_load.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/06_SAUVEGARDE_ET_CONFIGURATION/04_VALIDATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0047-sauvegarde_e`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0047` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0047`
Domaine : `06_SAUVEGARDE_ET_CONFIGURATION`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
