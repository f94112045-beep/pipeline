<!-- ID: JARDINS-0129 -->
# 15_OBJETS_ECONOMIE_RECOMPENSES — Implementation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Chaque objet doit etre reference par un systeme. Aucun orphelin.

**Étape Implementation :** Produire le contenu reel. C'est l'etape ou les quantites doivent etre atteintes.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/15_OBJETS_ECONOMIE_RECOMPENSES/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/resources.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/exploration.json` — produit plus tard par `19_EXPLORATION_ET_ANOMALIES`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/objects_economy.json` | `objects` | **70** |
| `data/canon/objects_economy.json` | `usages` | **40** |
| `data/canon/objects_economy.json` | `exchanges` | **25** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Secateur d'Instants**
- **Lanterne a Remanence**
- **Carnet des Continuites**
- **Fiole-Echos**
- **Balises de Retour**

## Système exigé : les objets clés font quelque chose

La bible nomme quatre objets clés et décrit ce qu'ils font. Aujourd'hui les
prompts n'en reprennent que les noms — et un nom sans règle d'usage produit un
objet qu'on ramasse et qui ne sert à rien.

`data/canon/objects_economy.json`, section `objets_cles`, une entrée par objet,
chacune avec : le **verbe** qu'il donne au joueur, ce qu'il exige pour être
utilisé, son effet mesurable, ses limites (usure, portée, durée, coût), et le
domaine qui exécute cet effet.

| Objet | Ce que la bible promet | Domaine qui l'exécute |
|---|---|---|
| Sécateur d'Instants | couper les excroissances temporelles | `19_EXPLORATION_ET_ANOMALIES` |
| Lanterne à Rémanence | révéler ce qu'un lieu a perdu | `11_MONDE_ET_BIOMES` |
| Fiole-Échos | stocker des sons, odeurs et images | `39_AUDIO_HOOKS` + `12B_CUISINE_ET_RECETTES` |
| Balises de Retour | créer un point de passage temporaire | `19_EXPLORATION_ET_ANOMALIES` |

Une ligne sans effet mesurable rend `FAIL`.

## Fichiers exacts a modifier

- `data/canon/objects_economy.json` — **ce prompt en est le producteur**
- `docs/reports/15_OBJETS_ECONOMIE_RECOMPENSES/02_IMPLEMENTATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_objects_economy.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/15_OBJETS_ECONOMIE_RECOMPENSES/02_IMPLEMENTATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0129-objets_econo`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0129` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0129`
Domaine : `15_OBJETS_ECONOMIE_RECOMPENSES`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
