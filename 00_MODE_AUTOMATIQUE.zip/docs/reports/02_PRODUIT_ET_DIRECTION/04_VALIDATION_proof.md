# Preuve — JARDINS-0019

## Prompt

- ID : `JARDINS-0019`
- Domaine : `02_PRODUIT_ET_DIRECTION`
- Étape : `04_VALIDATION`
- Date : `2026-09-20 23:02:00 +02:00`

## Validation du contenu

Les deux canons JSON sont valides, leurs sections dépassent les minimums et
chaque catégorie/règle possède un consommateur système. La palette respecte
les couleurs verrouillées du pipeline et les règles reprennent la résolution,
les tuiles et le filtrage canoniques.

## Comptes

| Livrable | Section | Compte | Minimum |
|---|---|---:|---:|
| `perimetre_contenu.json` | `categories` | 8 | 8 |
| `visual_profile.json` | `palette` | 13 | 1 |
| `visual_profile.json` | `regles` | 5 | 4 |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| validation JSON et consommateurs par script Python | 0 | `PRODUCT_CONTENT_PASS` |
| `python tools/audit_qualite_prompts.py` | 0 | 0 constat |
| `python tools/audit_chaine.py` | 0 | 0 constat |
| `python tools/audit_livrables.py` | 0 | 0 constat |

## Hashes

| Fichier | SHA-256 |
|---|---|
| `data/canon/perimetre_contenu.json` | `5A868583A51B8076FB72A556C50D8E1C922331E078B76F7F12E5FBC94AEE5905` |
| `data/canon/visual_profile.json` | `FD33E702AAAED02AF1BB5E43CBE217F311F325350DFBA5DF8766A7DCE388763E` |

## Décision

`PASS` — contenu et canons validés.
