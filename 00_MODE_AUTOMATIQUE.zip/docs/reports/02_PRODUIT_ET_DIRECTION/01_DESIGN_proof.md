# Preuve — JARDINS-0016

## Prompt

- ID : `JARDINS-0016`
- Domaine : `02_PRODUIT_ET_DIRECTION`
- Étape : `01_DESIGN`
- Date : `2026-09-20 22:58:00 +02:00`

## Conception arrêtée

`perimetre_contenu.json` contiendra huit catégories au minimum, chacune
portant une cible et une référence à un système consommateur. Le profil visuel
contiendra une palette non vide et au moins quatre règles couvrant la
résolution logique, l'échelle fenêtre, les tuiles et le filtrage NEAREST.

## Comptes

| Livrable | Section | Minimum | Produit à cette étape |
|---|---|---:|---:|
| `data/canon/perimetre_contenu.json` | `categories` | 8 | 0 — design |
| `data/canon/visual_profile.json` | `palette` | 1 | 0 — design |
| `data/canon/visual_profile.json` | `regles` | 4 | 0 — design |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| `python tools/audit_qualite_prompts.py` | 0 | PASS |
| `python tools/audit_chaine.py` | 0 | PASS |
| `python tools/audit_livrables.py` | 0 | PASS |

## Hashes

| Fichier | SHA-256 |
|---|---|
| `02_PRODUIT_ET_DIRECTION/01_DESIGN.md` | `2A588178620B85B185AE464CA80B7C38409A6F7A924EC0A4A8D5F1A8DC43E910` |

## Décision

`PASS` — design complet ; production reportée à `JARDINS-0017`.
