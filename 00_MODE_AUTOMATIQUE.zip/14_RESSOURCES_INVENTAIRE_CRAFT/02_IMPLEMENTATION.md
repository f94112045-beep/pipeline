<!-- ID: JARDINS-0122 -->
# 14_RESSOURCES_INVENTAIRE_CRAFT — Implementation

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Les trois familles de ressources de la bible et leur transformation.

**Étape Implementation :** Produire le contenu reel. C'est l'etape ou les quantites doivent etre atteintes.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/14_RESSOURCES_INVENTAIRE_CRAFT/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/cultures_craft.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/objects_economy.json` — produit plus tard par `15_OBJETS_ECONOMIE_RECOMPENSES`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/resources.json` | `naturelles` | **7** |
| `data/canon/resources.json` | `memorielles` | **7** |
| `data/canon/resources.json` | `hybrides` | **4** |
| `data/canon/inventory.json` | `regles` | **5** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **bois pale**
- **fibres de pluie**
- **argile musicale**
- **champignons-lanternes**
- **sel de brume**
- **verre mat**
- **eclat de rire**
- **regret condense**
- **promesse intacte**
- **derniere image**
- **reve inacheve**
- **colere ancienne**
- **souvenir partage**

## Système exigé : déposer, ranger, réorganiser

Le sac est produit, mais aucun domaine ne produit le geste d'en sortir quelque
chose. Décision du propriétaire : **la Maison-Pépinière a un stockage.**

Dans `data/canon/inventory.json`, section `rangement` :

- **déposer** et **reprendre** un objet, depuis où, avec quelle interface ;
- la **capacité** du stockage du refuge, et ce qui arrive quand elle est
  atteinte — renvoie au cas limite « inventaire plein » de
  `05_MODELE_CANONIQUE_ET_ETATS` ;
- **réorganiser** : tri, déplacement, empilement, et ce qui est automatique ;
- ce qui **ne peut pas** être stocké (objets de quête en cours, souvenirs
  périssables) ;
- la **persistance** du contenu du stockage en sauvegarde — à nommer dans
  `06_SAUVEGARDE_ET_CONFIGURATION`.

Le meuble lui-même est produit par `12_BATIMENTS_ET_REFUGE`, son interface par
`10_MENUS_UX_ACCESSIBILITE`, ses icônes par `32_UI_ICONES_CODEX`.

## Fichiers exacts a modifier

- `data/canon/resources.json` — **ce prompt en est le producteur**
- `data/canon/inventory.json` — **ce prompt en est le producteur**
- `src/godot/inventory.gd`
- `docs/reports/14_RESSOURCES_INVENTAIRE_CRAFT/02_IMPLEMENTATION_proof.md`

## Vérification

```bash
godot --headless --path . --script res://tests/test_inventory_craft.gd
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/14_RESSOURCES_INVENTAIRE_CRAFT/02_IMPLEMENTATION_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0122-ressources_i`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0122` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0122`
Domaine : `14_RESSOURCES_INVENTAIRE_CRAFT`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
