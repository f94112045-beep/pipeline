<!-- ID: JARDINS-0275 -->
# JARDINS-0275 — Production Visuelle 3D de l'Objet : Ancre de Paroi

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Produire l'asset visuel 3D Blender **dédié et unique** pour l'objet canonique **Ancre de Paroi** (`PROP_ANCRE_DE_PAROI`).

- **Prompt ID** : `JARDINS-0275`
- **Asset ID** : `PROP_ANCRE_DE_PAROI`
- **Nom canonique** : `Ancre de Paroi`
- **Catégorie** : `materiau`
- **Canon source** : `data/canon/objects_economy.json#objet_ancre_de_paroi`

## Ce que ce prompt doit livrer
1. Un script Python Blender 3D DÉDIÉ et UNIQUE : `_PIPELINE_BLENDER/builders/props/PROP_ANCRE_DE_PAROI.py`. (Tout builder partagé ou générique est STRICTEMENT INTERDIT).
2. Une fiche de configuration JSON : `_PIPELINE_BLENDER/fiches/PROP_ANCRE_DE_PAROI.json` pointant vers son builder dédié.
3. Le rendu du fichier PNG de l'asset dans `assets/generated/props/PROP_ANCRE_DE_PAROI.png`.

## Consignes Obligatoires
1. **Règle du Builder Dédié Unique** : Écris la géométrie 3D Blender spécifique pour l'anatomie réelle de l'objet **Ancre de Paroi**. L'objet doit comporter ses composants 3D réels (ex: manche, goulot, lame, reliure, dôme, buse, charnière, ornements) et être immédiatement reconnaissable.
2. **Fond Transparent & Zéro Socle** : Centré sur fond transparent sans aucun socle ni boîte parasite au sol.
3. **Inspection Visuelle Individuelle** : Ouvre le PNG rendu avec tes outils de vision, effectue les 3 Passes d'audit visuel (Anatomie, Esthétique Pixel Art, Unicité), et consigne le résultat avant d'accorder PASS.

## Lecture obligatoire
1. `../00_CONTRAT_COMMUN.md` — règles universelles de la chaîne ;
2. `../00_BIBLE_DU_JEU.md` — source de vérité narrative ;
3. `data/canon/objects_economy.json` — canon d'entrée des objets.

## Décision

Rendre PASS si le prompt a réussi. Sinon rendre FAIL ou BLOCKED.


## Procedure de Rollback Git
Si échec, exécuter `git reset --hard` et supprimer la branche temporaire.
