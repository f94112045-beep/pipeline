# Preuve — JARDINS-0005

## Prompt

- ID : `JARDINS-0005`
- Domaine : `00_INITIALISATION`
- Étape : `04_VALIDATION`
- Date : `2026-09-20 22:43:00 +02:00`

## Validation du contenu

Le test vérifie le chargement réel du canon, `Nacreval`, le personnage
canonique, les sept biomes, le périmètre, un objet clé, le projet Godot et la
scène principale. Les erreurs de fichier absent, JSON invalide, monde absent,
compte de biomes incorrect, périmètre absent et objet clé absent retournent un
code non nul.

## Comptes par section

| Section | Compte | Minimum |
|---|---:|---:|
| `canonical_characters` | 1 | 1 |
| `biomes` | 7 | 7 |
| `perimetre_contenu` | 1 | 1 |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| Godot console `--headless --path C:\Users\daric\OneDrive\Bureau\Les-Jardins-de-l-Heure-Creuse-V4-AUTO --script res://tests/test_boot.gd` | 0 | BOOT PASS |
| `python tools/audit_chaine.py` | 0 | PASS |
| `python tools/audit_livrables.py` | 0 | PASS technique ; constats futurs uniquement |

## Hashes

| Fichier | SHA-256 |
|---|---|
| `tests/test_boot.gd` | `CA66E698005BBC487DD60B3CAE40D4D05B05AF1115A0323D0C23A0475F8A380B` |

## Décision

`PASS` — le contenu canonique et les erreurs attendues sont vérifiés.
