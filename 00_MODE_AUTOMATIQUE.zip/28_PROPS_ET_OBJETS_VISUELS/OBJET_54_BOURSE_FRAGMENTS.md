<!-- ID: JARDINS-0293 -->
# JARDINS-0293 — Production Visuelle 3D de l'Objet : Bourse a Fragments

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Produire l'asset visuel 3D Blender **dédié et unique** pour l'objet canonique **Bourse a Fragments** (`PROP_BOURSE_FRAGMENTS`).

- **Prompt ID** : `JARDINS-0293`
- **Asset ID** : `PROP_BOURSE_FRAGMENTS`
- **Nom canonique** : `Bourse a Fragments`
- **Catégorie** : `outil`
- **Canon source** : `data/canon/objects_economy.json#objet_bourse_fragments`

## Ce que ce prompt doit livrer
1. Un script Python Blender 3D DÉDIÉ et UNIQUE : `_PIPELINE_BLENDER/builders/props/PROP_BOURSE_FRAGMENTS.py`. (Tout builder partagé ou générique est STRICTEMENT INTERDIT).
2. Une fiche de configuration JSON : `_PIPELINE_BLENDER/fiches/PROP_BOURSE_FRAGMENTS.json` pointant vers son builder dédié.
3. Le rendu du fichier PNG de l'asset dans `assets/generated/props/PROP_BOURSE_FRAGMENTS.png`.

## Consignes Obligatoires
1. **Règle du Builder Dédié Unique** : Écris la géométrie 3D Blender spécifique pour l'anatomie réelle de l'objet **Bourse a Fragments**. L'objet doit comporter ses composants 3D réels (ex: manche, goulot, lame, reliure, dôme, buse, charnière, ornements) et être immédiatement reconnaissable.
2. **Fond Transparent & Zéro Socle** : Centré sur fond transparent sans aucun socle ni boîte parasite au sol.
3. **Inspection Visuelle Individuelle** : Ouvre le PNG rendu avec tes outils de vision, effectue les 3 Passes d'audit visuel (Anatomie, Esthétique Pixel Art, Unicité), et consigne le résultat avant d'accorder PASS.

## Lecture obligatoire
1. `../00_CONTRAT_COMMUN.md` — règles universelles de la chaîne ;
2. `../00_BIBLE_DU_JEU.md` — source de vérité narrative ;
3. `data/canon/objects_economy.json` — canon d'entrée des objets.

## Décision

Rendre PASS si le prompt a réussi. Sinon rendre FAIL ou BLOCKED.


## Procedure de Rollback Git
Si échec, exécuter `git reset --hard` et supprimer la branche temporaire.
