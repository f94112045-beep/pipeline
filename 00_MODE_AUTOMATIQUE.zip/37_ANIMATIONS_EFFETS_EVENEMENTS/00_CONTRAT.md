<!-- ID: JARDINS-0370 -->
# 37_ANIMATIONS_EFFETS_EVENEMENTS — Contrat

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

Festivals, anomalies, apparitions, Dernier Cycle.

**Étape Contrat :** Etablir le contrat du domaine : ce qui sera produit, en quelle quantite, avec quelles entrees et quelles preuves. AUCUNE production a cette etape.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 406 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/37_ANIMATIONS_EFFETS_EVENEMENTS/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/calendar.json`
- `data/canon/narrative.json`
- `data/canon/exploration.json`
- `data/canon/factions.json`
- `data/canon/daily_loop.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/event_anim.json` | `animations` | **15** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.


## Inventaire nominatif — ce qui doit exister, nommement

Les **cinq festivals** de la bible : Nuit des Lanternes Vides · Repas des
Inconnus · Fete des Chemins · Jour Sans Nom · Marche des Possibles.

Plus : changement de saison (5 transitions) · apparition d'une anomalie ·
reconfiguration nocturne d'une ruine · **Dernier Cycle** (fusion des regions).

Un compte protege du vide ; il ne protege pas de l'oubli. Chaque entree de cette liste doit se retrouver dans le manifeste du domaine, et le rapport de gate doit le montrer.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Dernier Cycle**


## Production d'assets — moteur obligatoire

Les images passent par le moteur Blender du projet :

```bash
python ../_PIPELINE_BLENDER/build_asset.py --fiche ../_PIPELINE_BLENDER/fiches/<ASSET_ID>.json
```

**Lecture obligatoire avant de produire :**
`../_PIPELINE_BLENDER/GUIDE_OUTILS.md` (quel outil pour quel besoin, et lequel
n'est pas Blender) et `../_PIPELINE_BLENDER/art_direction.json` (le canon :
palette, caméra, lumière, résolution, budgets).

Si l'asset visé n'a pas encore de builder, écrire d'abord le builder en suivant
`../_PIPELINE_BLENDER/GUIDE_ECRIRE_UN_BUILDER.md`.

`BLOCKED` n'est pas un échec : c'est le moteur qui refuse de produire un asset
faux. Corriger la cause nommée, jamais contourner le contrôle.

## Précontrôle obligatoire — avant de produire ou de valider

**À lancer en premier, avant d'écrire la moindre ligne de ce domaine :**

```bash
python tools/precontrole_domaine.py 37_ANIMATIONS_EFFETS_EVENEMENTS
```

Il doit afficher `PRECONTROLE_PASS`. Tant qu'il affiche
`PRECONTROLE_BLOCKED`, **ne rien produire et ne rien valider** : rendre
`BLOCKED` en recopiant les lignes `MANQUE` telles quelles.

Il vérifie les sept choses dont dépend ce domaine :

1. les **canons d'entrée** existent et portent leurs sections ;
2. une **fiche de production** existe par asset attendu ;
3. chaque fiche désigne un **builder qui existe réellement** ;
4. le **format final exact** attendu par les tests est en place ;
5. les **quantités et variantes** sont celles du périmètre ;
6. les **outils de test** existent et sont lançables ;
7. le **manifeste** et le **chemin de preuve** sont connus.

**Pourquoi.** Le domaine du terrain a été validé trois fois de suite sur une
dépendance découverte trop tard : le design a déclaré sept tilesets conçus,
l'intégration a découvert que les sept fiches et les sept builders n'existaient
pas, puis la validation a découvert que les vrais `tileset.json` et leurs 47
configurations `blob47` manquaient. Chaque étape validait ce qu'elle voyait.

**Interdit, quelle que soit la pression :** créer un fichier vide pour
satisfaire le précontrôle, dupliquer une tuile ou un sprite pour atteindre un
compte, désactiver une vérification, ou abaisser un seuil. Une dépendance
manquante est une information, pas un obstacle.

## Fichiers exacts a modifier

- `docs/reports/37_ANIMATIONS_EFFETS_EVENEMENTS/00_CONTRAT_proof.md`

## Vérification

```bash
python tools/audit_qualite_prompts.py
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/37_ANIMATIONS_EFFETS_EVENEMENTS/00_CONTRAT_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0370-animations_e`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0370` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0370`
Domaine : `37_ANIMATIONS_EFFETS_EVENEMENTS`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
