# Preuve — JARDINS-0014

## Prompt

- ID : `JARDINS-0014`
- Domaine : `01_VERSIONNAGE_ET_ROLLBACK`
- Étape : `06_GATE`
- Date : `2026-09-20 22:56:00 +02:00`

## Gate du domaine

Le dépôt Git est initialisé, les conventions sont documentées, les branches de
prompt existent, les étiquettes de gate sont créées et un rollback par hash a
été vérifié.

## Comptes

| Section | Compte | Minimum |
|---|---:|---:|
| conventions versionnage | 8 | 1 |
| conventions rollback | 3 | 1 |
| branches de prompt | 4 | 1 |
| tags de gate | 3 | 1 |
| rollbacks vérifiés | 1 | 1 |

## Vérifications

| Commande | Code retour | Résultat |
|---|---:|---|
| `python tools/audit_qualite_prompts.py` | 0 | 0 constat |
| `python tools/audit_chaine.py` | 0 | 0 constat |
| `python tools/audit_livrables.py` | 0 | 0 constat |
| `git tag --list gate/JARDINS-*` | 0 | `gate/JARDINS-0010`, `gate/JARDINS-0011`, `gate/JARDINS-0013` |
| rollback par `git restore --source gate/JARDINS-0011` | 0 | hash restauré |

## Décision

`PASS` — domaine `01_VERSIONNAGE_ET_ROLLBACK` terminé.
