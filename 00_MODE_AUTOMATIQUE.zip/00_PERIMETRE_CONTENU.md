# Périmètre de contenu — les quantités

> **Ambition visée : densité comparable à Stardew Valley, casting resserré.**

Un concept, même excellent, ne contient aucune quantité. Une chaîne exécute ce
qui est écrit : « traiter les cultures » est **satisfait par une seule culture**,
et personne n'a désobéi. Ce fichier existe pour que cela ne se reproduise pas.

---

## Les deux paliers

- **Palier 1** — le plancher de conception : sous ce nombre, le système n'a
  aucun sens (7 biomes exigent 7 ressources propres). Il sert à justifier les
  nombres, **il n'est plus le seuil de production**.
- **Cible** — **c'est elle qui bloque.** Décision du propriétaire : un domaine
  ne peut pas être déclaré terminé sous la cible, et `tools/audit_livrables.py`
  le refuse.

> **Pourquoi ce changement.** Les domaines exigeaient le palier 1 pendant que
> le budget ci-dessous était calculé sur la cible. Une IA aurait livré 16
> cultures au lieu de 40, obtenu `PASS` partout, et la chaîne se serait achevée
> sur un jeu trois fois plus petit que demandé — sans que personne désobéisse.
> C'est l'erreur d'origine du projet, remontée d'un étage.

| Catégorie | Palier 1 (conception) | **Cible (bloquante)** | Note |
|---|---|---|---|
| **Cultures** | 16 | 40 | réparties sur les saisons ; graine ≠ récolte ; 3 étapes de croissance |
| **Objets (total)** | 120 | 136 | ressources, récoltes, artisanat, outils, matériaux, quête, codex |
| **Recettes de craft** | 25 | 60 | entrées toujours ≠ sortie |
| **PNJ** | 12 | 14 | le Semeur est le joueur et ne compte pas |
| **Dialogues par PNJ** | 15 | 15 | |
| **Quêtes** | 20 | 45 | principales, secondaires, liées aux PNJ |
| **Créatures** | 12 | 20 | réparties sur les 4 familles de la bible |
| **Boss** | 4 | 4 | **CLOS** — ceux de la bible |
| **Saisons** | 5 | 5 | **CLOS** |
| **Festivals** | 5 | 5 | **CLOS** |
| **Événements de calendrier** | 8 | 20 | |
| **Biomes** | 7 | 7 | **CLOS** |
| **Fins** | 5 | 5 | **CLOS** |
| **Bruitages** | 40 | 80 | |
| **Ambiances** | 7 | 10 | une par biome minimum |

> **Pourquoi 150 objets et non 300.** La cible etait de 300. A la production,
> il est apparu qu'au-dela de ~150 l'agent ne produisait plus des idees mais une
> grille : huit prefixes croises avec quarante complements. Un compte atteint par
> combinaison n'est pas du contenu. 150 objets reellement distincts valent mieux
> que 300 cases remplies -- et des **variantes declarees** (champ `variante_de`)
> peuvent s'y ajouter sans limite, elles, puisqu'elles assument d'etre des
> variantes.

> **Le compte des objets se lit sur trois canons**, pour ne rien dupliquer :
> 70 objets manufactures (`objects_economy.json`), 18 ressources
> (`resources.json`) et 48 graines attachees aux cultures
> (`cultures_craft.json`), soit **136 objets** au total. Les familles de
> semences, de matieres et de fragments ont ete retirees de `objects_economy`
> parce qu'elles existaient deja ailleurs : un objet n'a qu'un seul producteur.

> **Pourquoi 15 repliques par personnage et non 30.** A la production, les 30
> repliques d'Orven ont montre que la qualite visee etait atteignable ; les 420
> d'un coup ne l'etaient pas, et l'agent a rendu `BLOCKED` plutot que de
> recombiner des fragments -- ce qui etait le comportement attendu. 15 repliques
> ecrites valent mieux que 30 assemblees, et un dialogue s'ajoute a tout moment
> sans rien casser, contrairement a un systeme. Orven garde ses 30.

> **Les quantites derivees sont recalculees depuis le canon.** Ce tableau
> annoncait « 40 cultures x 3 etapes = 120 sprites », ecrit avant que le canon
> n'existe. Le canon declare 48 cultures et 5 etapes : 240 images. Tous les
> controles verifiaient « au moins 120 » et 120 etait atteint -- la chaine a
> donc produit trois etapes sur cinq en respectant une exigence devenue fausse.
> Le precontrole recalcule desormais ces nombres a chaque passage.

**La musique est hors périmètre** : produite séparément, en fin de projet.

---

## Comment ces nombres ont été obtenus

Ils ne sont pas arbitraires. Deux bornes les encadrent :

**Le plancher — rien ne doit manquer.**
7 biomes ⇒ au moins 7 ressources propres : un lieu sans matière n'a aucune
raison d'être visité. 14 PNJ ⇒ 14 emplois du temps, 14 jeux de relations.
Chaque culture ⇒ une graine et une récolte distinctes. Chaque système
consommateur (craft, récompense, construction) ⇒ sa matière.

**Le plafond — rien ne doit être en trop.**
**Aucun élément sans usage.** Tout objet doit être référencé par au moins un
système. Un objet que rien ne référence deviendra un sprite inutile au moment de
la production visuelle.

Trop d'éléments ⇒ des orphelins ⇒ `FAIL`.
Trop peu ⇒ un système à vide ⇒ `FAIL`.

---

## Ce que ça coûte, pour que ce soit assumé

| Poste | Calcul | Total |
|---|---|---|
| Sprites de cultures | 48 × 5 étapes | 240 |
| Images de personnages | 15 × 4 directions × 4 images | 240 |
| Sprites d'objets | 1 par objet | 150 |
| Créatures et boss | 16 à 24 sujets animés | ~80 images |
| Bruitages et ambiances | | 50 à 90 fichiers |

C'est précisément ce que les deux moteurs rendent tenable : **un builder
paramétré produit toute une famille**. Une culture = un builder, trois étapes.

---

## Ce qui est CLOS et ne se rediscute pas

Les **7 biomes**, les **4 boss**, les **5 saisons**, les **5 festivals** et les
**5 fins** viennent de `00_BIBLE_DU_JEU.md`. Leur nombre et leurs noms sont
fixés. Un prompt qui en ajoute ou en renomme un est en faute.

Le **casting à 14 PNJ** se ferme au domaine `16_PNJ_CASTING`. Après lui, ajouter
un personnage impose de rétro-alimenter dialogues, horaires, relations, sprites,
portraits et animations — c'est-à-dire de rouvrir sept domaines.
