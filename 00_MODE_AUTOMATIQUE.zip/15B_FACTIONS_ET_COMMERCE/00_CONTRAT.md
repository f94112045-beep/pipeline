<!-- ID: JARDINS-0134 -->
# 15B_FACTIONS_ET_COMMERCE — Contrat

> **Contrat commun obligatoire** — lire et appliquer `../00_CONTRAT_COMMUN.md` avant d'exécuter ce prompt.

## Mission

La Cite Suspendue de Rive-Haute vit de luttes entre plusieurs visions du passe : commerce, politique, intrigues, et des batiments qui se deplacent quand une faction gagne en influence. Sans systeme de factions, la Cite n'est qu'un decor de plus.

**Étape Contrat :** Etablir le contrat du domaine : ce qui sera produit, en quelle quantite, avec quelles entrees et quelles preuves. AUCUNE production a cette etape.

## Lecture obligatoire

1. `../00_CONTRAT_COMMUN.md` — les règles qui valent pour les 392 prompts ;
2. `../00_BIBLE_DU_JEU.md` — **source de vérité narrative : les noms ne s'inventent pas** ;
3. `../00_PERIMETRE_CONTENU.md` — les quantités visées ;
4. le rapport du domaine précédent, dans `docs/reports/15B_FACTIONS_ET_COMMERCE/`.

## Canons lus en entrée

Ce domaine **consomme** ces canons, tous produits par des domaines
exécutés avant lui. Il ne les modifie pas ; son livrable doit être
cohérent avec eux.

- `data/canon/objects_economy.json`
- `data/canon/world_architecture.json`

Si l'un d'eux manque alors que son domaine producteur est déjà passé,
rendre `BLOCKED` en le nommant.

### Canons attendus plus tard — contrat, pas dépendance

Ces canons **n'existent pas encore** : leurs domaines producteurs
viennent après celui-ci. **Ne jamais rendre `BLOCKED` pour eux, ne
jamais les créer ici.** Ce domaine écrit ce qu'il en attend ; c'est au
domaine producteur de s'y conformer quand son tour viendra.

- `data/canon/casting.json` — produit plus tard par `16_PNJ_CASTING`
- `data/canon/calendar.json` — produit plus tard par `20_TEMPS_SAISONS_FESTIVALS`

Ne jamais écrire dans un canon produit par un autre domaine.

## Ce que ce domaine doit livrer, chiffré

| Fichier | Section | Minimum |
|---|---|---|
| `data/canon/factions.json` | `factions` | **4** |
| `data/canon/factions.json` | `relations_inter_factions` | **6** |
| `data/canon/factions.json` | `effets_d_influence` | **8** |
| `data/canon/commerce.json` | `marchands` | **6** |
| `data/canon/commerce.json` | `offres` | **30** |
| `data/canon/commerce.json` | `taux_par_faction` | **4** |

Un domaine ne peut pas être déclaré terminé sous ces minimums :
`python tools/audit_livrables.py` le refuse.

## Inventaire nominatif — ce qui doit exister, nommement

**Quatre factions minimum**, chacune avec : une vision du passe, un
territoire, une ressource qu'elle controle, et ce qu'elle exige du joueur.

**L'influence est une valeur suivie** : ce qui la fait monter, ce qui la fait
baisser, et **huit effets visibles** au moins -- des batiments qui se deplacent,
des prix qui changent, des quartiers qui s'ouvrent ou se ferment, des PNJ qui
changent d'attitude.

**Le commerce** : six marchands, trente offres, des taux qui varient selon
l'influence. Vendre et acheter sont des VERBES du joueur : ils doivent exister
en jeu, pas seulement dans le canon.

Le **Marche des Possibles** (festival) vend des objets venus de versions
alternatives du monde : il depend de ce domaine.

## Entités nommées à respecter

Ces noms viennent de `00_BIBLE_DU_JEU.md` et **ne s'inventent pas** :

- **Cite Suspendue de Rive-Haute**
- **Marche des Possibles**

## Fichiers exacts a modifier

- `docs/reports/15B_FACTIONS_ET_COMMERCE/00_CONTRAT_proof.md`

## Vérification

```bash
# (le test Godot n'est PAS exige a cette etape : elle ne produit aucun
#  code. Il devient obligatoire des `02_IMPLEMENTATION`.)
python tools/audit_chaine.py
python tools/audit_livrables.py
```

## PASS

`PASS` uniquement si : le livrable de cette étape existe, la commande de
vérification a été exécutée et son code retour consigné, le rapport est écrit
dans `docs/reports/15B_FACTIONS_ET_COMMERCE/00_CONTRAT_proof.md`, et les hashes sont
reportés.

**PASS exige EN OUTRE que le contenu existe** : chaque section annoncée
ci-dessus doit contenir au moins le minimum d'entrées réelles, chacune
référencée par un système du jeu, et le rapport doit en donner le **compte
section par section**. Un `PASS` prononcé sur une structure vide vaut `FAIL`
(voir `00_CONTRAT_COMMUN.md`, section « Contenu livré »).

Si la matière dépend d'un domaine non encore exécuté, rendre `BLOCKED` en le
nommant. Jamais `PASS`.

**PASS exige EN OUTRE la trace de boucle** (mode automatique) : la ligne de cet
identifiant existe dans `docs/evidence/JOURNAL_AUTO.md`, son `status` est à jour
dans `PROMPT_DEPENDENCY_AUDIT.csv`, et `ETAT_AUTO.md` désigne le prompt suivant.
Une étape faite mais non tracée vaut `FAIL` : en exécution automatique, ce qui
n'est pas journalisé est invérifiable.

## FAIL / BLOCKED

`FAIL` : le livrable existe mais ne tient pas ses critères. Aller en
`05_CORRECTION`.
`BLOCKED` : une dépendance manque. Nommer le prompt qui doit la fournir.

## Rollback

Branche `rebuild/JARDINS-0134-factions_et_`, commits préfixés par l'identifiant, étiquette
`gate/JARDINS-0134` après un `PASS`. En cas d'échec : `git reset --hard gate/<précédent>`.

## ID stable et domaine

ID : `JARDINS-0134`
Domaine : `15B_FACTIONS_ET_COMMERCE`
Prochain prompt autorisé : lire `PROMPT_DEPENDENCY_AUDIT.csv`, colonne
`next_allowed` de la ligne de cet identifiant.

**Mode automatique — ne pas s'arrêter ici.** Après le gate : inscrire le
résultat au registre, ajouter la ligne au journal `docs/evidence/JOURNAL_AUTO.md`,
réécrire `ETAT_AUTO.md`, puis **exécuter immédiatement le prochain prompt
autorisé**, sans demander d'accord. Ne s'arrêter que pour un motif de la liste
des arrêts de `00_MODE_AUTOMATIQUE.md` — et alors, rendre le bloc d'arrêt.
